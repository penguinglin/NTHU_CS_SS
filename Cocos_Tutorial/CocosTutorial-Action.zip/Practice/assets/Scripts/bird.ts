import { GameManager } from "./GameManager";

const { ccclass, property } = cc._decorator;

@ccclass
export class bird extends cc.Component {

    anchor1: cc.Node;
    anchor2: cc.Node;

    draggable: boolean = true;
    attachRope: boolean = true;

    initPos: cc.Vec2;
    startPos: cc.Vec2;

    motorJoint: cc.MotorJoint;
    ropeJoint: cc.RopeJoint;
    rb: cc.RigidBody;

    maxLength: number;

    score: number;

    @property(cc.Node)
    scorePoints = null;

    @property(cc.Prefab)
    smokePrefabs: cc.Prefab = null;

    @property(GameManager)
    GameMgr: GameManager = null;

    // ========== TODO 3.1 ==========
    // 1. Define birdPrefabs
    // ==============================

    onLoad() {
        cc.director.getPhysicsManager().enabled = true;
    }

    start() {
        this.initProperties();
        this.initResetButton();
        this.score = 0;
    }


    update() {
        var diff = this.initPos.sub(this.node.position);
        var angle = Math.atan2(diff.x, diff.y);
        if (this.node.position.sub(this.initPos).mag() <= 10) {
            if (!this.draggable) {
                this.motorJoint.enabled = false;
                this.ropeJoint.enabled = false;
                this.rb.angularVelocity = -angle * 20;
                this.attachRope = false;
                this.anchor1.setPosition(this.initPos.add(cc.v2(-20, 0)));
                this.anchor2.setPosition(this.initPos.add(cc.v2(-20, 0)));
            }
        } else {
            if (this.attachRope) {
                this.node.angle = - cc.misc.radiansToDegrees(angle) + 90;

                this.anchor1.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
                this.anchor2.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
            }
        }
    }

    initProperties() {
        this.anchor1 = cc.find("Canvas/Slingshot/SlingshotFront/anchor1");
        this.anchor1.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.anchor2 = cc.find("Canvas/Slingshot/SlingshotBack/anchor2");
        this.anchor2.setPosition(this.node.position.add(cc.v2(-20, 0)));

        this.motorJoint = this.getComponent(cc.MotorJoint);
        this.ropeJoint = this.getComponent(cc.RopeJoint);
        this.rb = this.getComponent(cc.RigidBody);

        this.initPos = this.node.position;
        this.startPos = this.node.position;

        this.maxLength = this.ropeJoint.maxLength;
    }

    initResetButton() {
        let clickEventHandler = new cc.Component.EventHandler();
        clickEventHandler.target = this.node;
        clickEventHandler.component = "bird";
        clickEventHandler.handler = "reset";

        cc.find("Canvas/Reset").getComponent(cc.Button).clickEvents.push(clickEventHandler);
    }

    reset() {
        this.node.setPosition(this.initPos);

        this.rb.linearVelocity = cc.Vec2.ZERO;
        this.rb.angularVelocity = 0;
        this.rb.gravityScale = 0;

        this.node.angle = 0;
        this.draggable = true;
        this.attachRope = true;
    }

    onEnable() {
        this.node.on(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    }

    onDisable() {
        this.node.off(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    }

    _onTouchBegan(event) {
        if (!this.enabledInHierarchy) return;

        if (this.draggable) {
            this.startPos = this.node.position;
            this.motorJoint.enabled = false;
            this.rb.gravityScale = 0;
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    }

    _onTouchMove(event) {
        if (!this.enabledInHierarchy) return;

        if (this.draggable) {
            let start = event.getStartLocation();
            let cur = event.getLocation();
            cur.subSelf(start);

            let cur_v = cc.v2(cur.x, cur.y);
            if (cur_v.mag() > this.maxLength) {
                cur_v.normalizeSelf().mulSelf(this.maxLength);
            }

            this.node.setPosition(this.startPos.add(cur_v));

            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }

        event.stopPropagation();
    }

    _onTouchEnded(event) {
        if (!this.enabledInHierarchy) return;

        this.dragEnd();

        event.stopPropagation();
    }

    _onTouchCancel(event) {
        if (!this.enabledInHierarchy) return;

        this.dragEnd();

        event.stopPropagation();
    }

    dragEnd() {
        if (!this.draggable) return;

        if (this.node.position.sub(this.startPos).mag() > 10) {
            this.draggable = false;
        }

        this.motorJoint.enabled = true;

        this.rb.gravityScale = 1;
        this.rb.linearVelocity = cc.v2(1, 0);

        // ========== TODO 3.3 ==========
        // 1. Split to two birds after 0.5 sec.
        // ==============================

        this.GameMgr.playEffect();

    }

    // ========== TODO 3.2 ==========
    // 1. Instantiate another bird.
    // 2. Set the new bird's position to this bird's x and y + 10.
    // 3. Set the new bird's linearVelocity equals to this bird's velocity x and this bird's velocity (y + 50).
    // 4. Use addChild() function to place prefab into scene.
    // 5. Destroy the split bird after 5 seconds, if there exist the smoke generated by the bird, also destroy it.
    // ==============================


    updateScore(number) {
        this.score += number;
        this.scorePoints.getComponent(cc.Label).string = this.score.toString();
    }


    onBeginContact(contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact")
            console.log(contact.getWorldManifold().points);

            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);

            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);

            this.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag

            console.log("Trigger");

            other.node.destroy();
            this.updateScore(10);
        }
        // ========== TODO 2.1 ==========
        // 1. If contact with a spike, reset the bird 
        //    to the initial position after 1 second.
        // ==============================
    }



    onEndContact(contact, self, other) {
        if (other.tag == 1) other.tag = 0;
    }
}
