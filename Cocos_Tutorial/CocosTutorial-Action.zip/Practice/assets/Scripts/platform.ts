const { ccclass, property } = cc._decorator;

@ccclass
export default class Platform extends cc.Component {

    @property(cc.Node)
    Vertical_platform: cc.Node = null;

    @property(cc.Node)
    Horizontal_platform: cc.Node = null;

    @property(cc.Node)
    Vertical_spike: cc.Node = null;

    @property(cc.Node)
    Horizontal_spike: cc.Node = null;

    // ========== TODO 1.2 ==========
    // 1. Let platforms continue to move during the game.
    start() {

        // ========= TODO 1.3.1 =========
        // 1. Let the vertical spike move 
        // ==============================
    }
    // ==============================

    // ========= TODO 1.3.2 =========
    // 1. Let the horizontal spike always stay at the initial local position,
    //    So, it will move with its parent correctly
    // ==============================


    // ========== TODO 1.1 ==========
    // 1. Define the action sequence.
    //    (Hint: you can use cc.sequence and cc.easeInOut to help you design actions.)
    // 2. Use moveDir to decide whether you should move vertical or horizontal.
    // 3. Let a variable action represent the "repeated action".
    //    (Hint: cc.repeatForever)
    // 4. Use schedule function to set the delay time when game start.
    // ==============================


    spikeMove(delayTime: number, spike: cc.Node) {
        let action: cc.Action;
        let easeRate: number = 2;
        var sequence = cc.sequence(cc.moveBy(1, 40, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(1, -40, 0).easing(cc.easeInOut(easeRate)));
        action = cc.repeatForever(sequence);
        this.scheduleOnce(function () {
            spike.runAction(action);
        }, delayTime);
    }

}