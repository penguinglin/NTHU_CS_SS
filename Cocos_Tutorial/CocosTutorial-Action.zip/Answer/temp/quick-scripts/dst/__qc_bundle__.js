
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Scripts/GameManager');
require('./assets/Scripts/anchor');
require('./assets/Scripts/bird');
require('./assets/Scripts/menu');
require('./assets/Scripts/platform');
require('./assets/Scripts/splitBirds');
require('./assets/migration/use_reversed_rotateTo');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/bird.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6d012QIyy5FOLpzct9wIDzm', 'bird');
// Scripts/bird.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.bird = void 0;
var GameManager_1 = require("./GameManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var bird = /** @class */ (function (_super) {
    __extends(bird, _super);
    function bird() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.draggable = true;
        _this.attachRope = true;
        _this.scorePoints = null;
        _this.smokePrefabs = null;
        _this.GameMgr = null;
        // ========== TODO 3.1 ==========
        // 1. Define birdPrefabs
        _this.birdPrefabs = null;
        return _this;
    }
    // ==============================
    bird.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    bird.prototype.start = function () {
        this.initProperties();
        this.initResetButton();
        this.score = 0;
    };
    bird.prototype.update = function () {
        var diff = this.initPos.sub(this.node.position);
        var angle = Math.atan2(diff.x, diff.y);
        if (this.node.position.sub(this.initPos).mag() <= 10) {
            if (!this.draggable) {
                this.motorJoint.enabled = false;
                this.ropeJoint.enabled = false;
                this.rb.angularVelocity = -angle * 20;
                this.attachRope = false;
                this.anchor1.setPosition(this.initPos.add(cc.v2(-20, 0)));
                this.anchor2.setPosition(this.initPos.add(cc.v2(-20, 0)));
            }
        }
        else {
            if (this.attachRope) {
                this.node.angle = -cc.misc.radiansToDegrees(angle) + 90;
                this.anchor1.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
                this.anchor2.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
            }
        }
    };
    bird.prototype.initProperties = function () {
        this.anchor1 = cc.find("Canvas/Slingshot/SlingshotFront/anchor1");
        this.anchor1.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.anchor2 = cc.find("Canvas/Slingshot/SlingshotBack/anchor2");
        this.anchor2.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.motorJoint = this.getComponent(cc.MotorJoint);
        this.ropeJoint = this.getComponent(cc.RopeJoint);
        this.rb = this.getComponent(cc.RigidBody);
        this.initPos = this.node.position;
        this.startPos = this.node.position;
        this.maxLength = this.ropeJoint.maxLength;
    };
    bird.prototype.initResetButton = function () {
        var clickEventHandler = new cc.Component.EventHandler();
        clickEventHandler.target = this.node;
        clickEventHandler.component = "bird";
        clickEventHandler.handler = "reset";
        cc.find("Canvas/Reset").getComponent(cc.Button).clickEvents.push(clickEventHandler);
    };
    bird.prototype.reset = function () {
        this.node.setPosition(this.initPos);
        this.rb.linearVelocity = cc.Vec2.ZERO;
        this.rb.angularVelocity = 0;
        this.rb.gravityScale = 0;
        this.node.angle = 0;
        this.draggable = true;
        this.attachRope = true;
    };
    bird.prototype.onEnable = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    };
    bird.prototype.onDisable = function () {
        this.node.off(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    };
    bird.prototype._onTouchBegan = function (event) {
        if (!this.enabledInHierarchy)
            return;
        if (this.draggable) {
            this.startPos = this.node.position;
            this.motorJoint.enabled = false;
            this.rb.gravityScale = 0;
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    };
    bird.prototype._onTouchMove = function (event) {
        if (!this.enabledInHierarchy)
            return;
        if (this.draggable) {
            var start = event.getStartLocation();
            var cur = event.getLocation();
            cur.subSelf(start);
            var cur_v = cc.v2(cur.x, cur.y);
            if (cur_v.mag() > this.maxLength) {
                cur_v.normalizeSelf().mulSelf(this.maxLength);
            }
            this.node.setPosition(this.startPos.add(cur_v));
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    };
    bird.prototype._onTouchEnded = function (event) {
        if (!this.enabledInHierarchy)
            return;
        this.dragEnd();
        event.stopPropagation();
    };
    bird.prototype._onTouchCancel = function (event) {
        if (!this.enabledInHierarchy)
            return;
        this.dragEnd();
        event.stopPropagation();
    };
    bird.prototype.dragEnd = function () {
        if (!this.draggable)
            return;
        if (this.node.position.sub(this.startPos).mag() > 10) {
            this.draggable = false;
        }
        this.motorJoint.enabled = true;
        this.rb.gravityScale = 1;
        this.rb.linearVelocity = cc.v2(1, 0);
        // ========== TODO 3.3 ==========
        // 1. Split to two birds after 0.5 sec.
        this.scheduleOnce(function () {
            this.split();
        }, 0.5);
        // ==============================
        this.GameMgr.playEffect();
    };
    // ========== TODO 3.2 ==========
    // 1. Instantiate another bird.
    // 2. Set the new bird's position to this bird's x and y + 10.
    // 3. Set the new bird's linearVelocity equals to this bird's velocity x and this bird's velocity (y + 50).
    // 4. Use addChild() function to place prefab into scene.
    // 5. Destroy the split bird after 5 seconds, if there exist the smoke generated by the bird, also destroy it.
    bird.prototype.split = function () {
        console.log("split");
        var bird_split = cc.instantiate(this.birdPrefabs);
        bird_split.setPosition(this.node.position.x, this.node.position.y + 10);
        bird_split.getComponent(cc.RigidBody).linearVelocity = cc.v2(this.rb.linearVelocity.x, this.rb.linearVelocity.y + 50);
        cc.find("Canvas/Slingshot").addChild(bird_split);
        this.scheduleOnce(function () {
            if (cc.find("Canvas/Environment/smoke2")) {
                cc.find("Canvas/Environment/smoke2").destroy();
            }
            bird_split.destroy();
        }, 5);
    };
    // ==============================
    bird.prototype.updateScore = function (number) {
        this.score += number;
        this.scorePoints.getComponent(cc.Label).string = this.score.toString();
    };
    bird.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact");
            console.log(contact.getWorldManifold().points);
            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);
            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);
            this.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag
            console.log("Trigger");
            other.node.destroy();
            this.updateScore(10);
        }
        // ========== TODO 2.1 ==========
        // 1. If contact with a spike, reset the bird 
        //    to the initial position after 1 second.
        else if (other.node.name == "Spike") {
            console.log("hurt");
            this.scheduleOnce(function () {
                this.reset();
            }, 1);
        }
        // ==============================
    };
    bird.prototype.onEndContact = function (contact, self, other) {
        if (other.tag == 1)
            other.tag = 0;
    };
    __decorate([
        property(cc.Node)
    ], bird.prototype, "scorePoints", void 0);
    __decorate([
        property(cc.Prefab)
    ], bird.prototype, "smokePrefabs", void 0);
    __decorate([
        property(GameManager_1.GameManager)
    ], bird.prototype, "GameMgr", void 0);
    __decorate([
        property(cc.Prefab)
    ], bird.prototype, "birdPrefabs", void 0);
    bird = __decorate([
        ccclass
    ], bird);
    return bird;
}(cc.Component));
exports.bird = bird;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcYmlyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZDQUE0QztBQUV0QyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUEwQix3QkFBWTtJQUF0QztRQUFBLHFFQW9RQztRQS9QRyxlQUFTLEdBQVksSUFBSSxDQUFDO1FBQzFCLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBYzNCLGlCQUFXLEdBQUcsSUFBSSxDQUFDO1FBR25CLGtCQUFZLEdBQWMsSUFBSSxDQUFDO1FBRy9CLGFBQU8sR0FBZ0IsSUFBSSxDQUFDO1FBRTVCLGlDQUFpQztRQUNqQyx3QkFBd0I7UUFFeEIsaUJBQVcsR0FBYyxJQUFJLENBQUM7O0lBcU9sQyxDQUFDO0lBcE9HLGlDQUFpQztJQUVqQyxxQkFBTSxHQUFOO1FBQ0ksRUFBRSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7SUFDbkQsQ0FBQztJQUVELG9CQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLENBQUM7SUFHRCxxQkFBTSxHQUFOO1FBQ0ksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNoRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDbEQsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztnQkFDaEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2dCQUMvQixJQUFJLENBQUMsRUFBRSxDQUFDLGVBQWUsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDN0Q7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUV6RCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3ZGO1NBQ0o7SUFDTCxDQUFDO0lBRUQsNkJBQWMsR0FBZDtRQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsd0NBQXdDLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEUsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUNsQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBRW5DLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFDOUMsQ0FBQztJQUVELDhCQUFlLEdBQWY7UUFDSSxJQUFJLGlCQUFpQixHQUFHLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4RCxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNyQyxpQkFBaUIsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFFcEMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUN4RixDQUFDO0lBRUQsb0JBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVwQyxJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUN0QyxJQUFJLENBQUMsRUFBRSxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztJQUMzQixDQUFDO0lBRUQsdUJBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFRCx3QkFBUyxHQUFUO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVELDRCQUFhLEdBQWIsVUFBYyxLQUFLO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxPQUFPO1FBRXJDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztZQUNoQyxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUM7WUFDekIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCwyQkFBWSxHQUFaLFVBQWEsS0FBSztRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDckMsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzlCLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFbkIsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyxJQUFJLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUM5QixLQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUNqRDtZQUVELElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFFaEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1NBQy9CO1FBRUQsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCw0QkFBYSxHQUFiLFVBQWMsS0FBSztRQUNmLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFZixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELDZCQUFjLEdBQWQsVUFBZSxLQUFLO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFZixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELHNCQUFPLEdBQVA7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVM7WUFBRSxPQUFPO1FBRTVCLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDbEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDMUI7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFL0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXJDLGlDQUFpQztRQUNqQyx1Q0FBdUM7UUFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNqQixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDUixpQ0FBaUM7UUFFakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUU5QixDQUFDO0lBRUQsaUNBQWlDO0lBQ2pDLCtCQUErQjtJQUMvQiw4REFBOEQ7SUFDOUQsMkdBQTJHO0lBQzNHLHlEQUF5RDtJQUN6RCw4R0FBOEc7SUFDOUcsb0JBQUssR0FBTDtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQ3hFLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDdEgsRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVqRCxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ2QsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLEVBQUU7Z0JBQ3RDLEVBQUUsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUNsRDtZQUNELFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN6QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDVixDQUFDO0lBQ0QsaUNBQWlDO0lBR2pDLDBCQUFXLEdBQVgsVUFBWSxNQUFNO1FBQ2QsSUFBSSxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQzNFLENBQUM7SUFHRCw2QkFBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQy9CLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxZQUFZO1lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUE7WUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUvQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM5QyxLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhELEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDZCxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRVIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUN4QjthQUNJLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0I7WUFFdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUV2QixLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDeEI7UUFDRCxpQ0FBaUM7UUFDakMsOENBQThDO1FBQzlDLDZDQUE2QzthQUN4QyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtZQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxZQUFZLENBQUM7Z0JBQ2QsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2pCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNUO1FBQ0QsaUNBQWlDO0lBQ3JDLENBQUM7SUFJRCwyQkFBWSxHQUFaLFVBQWEsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQzdCLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQUUsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQS9PRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzZDQUNDO0lBR25CO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7OENBQ1c7SUFHL0I7UUFEQyxRQUFRLENBQUMseUJBQVcsQ0FBQzt5Q0FDTTtJQUs1QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzZDQUNVO0lBL0JyQixJQUFJO1FBRGhCLE9BQU87T0FDSyxJQUFJLENBb1FoQjtJQUFELFdBQUM7Q0FwUUQsQUFvUUMsQ0FwUXlCLEVBQUUsQ0FBQyxTQUFTLEdBb1FyQztBQXBRWSxvQkFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdhbWVNYW5hZ2VyIH0gZnJvbSBcIi4vR2FtZU1hbmFnZXJcIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgY2xhc3MgYmlyZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgYW5jaG9yMTogY2MuTm9kZTtcclxuICAgIGFuY2hvcjI6IGNjLk5vZGU7XHJcblxyXG4gICAgZHJhZ2dhYmxlOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIGF0dGFjaFJvcGU6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIGluaXRQb3M6IGNjLlZlYzI7XHJcbiAgICBzdGFydFBvczogY2MuVmVjMjtcclxuXHJcbiAgICBtb3RvckpvaW50OiBjYy5Nb3RvckpvaW50O1xyXG4gICAgcm9wZUpvaW50OiBjYy5Sb3BlSm9pbnQ7XHJcbiAgICByYjogY2MuUmlnaWRCb2R5O1xyXG5cclxuICAgIG1heExlbmd0aDogbnVtYmVyO1xyXG5cclxuICAgIHNjb3JlOiBudW1iZXI7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBzY29yZVBvaW50cyA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHNtb2tlUHJlZmFiczogY2MuUHJlZmFiID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoR2FtZU1hbmFnZXIpXHJcbiAgICBHYW1lTWdyOiBHYW1lTWFuYWdlciA9IG51bGw7XHJcblxyXG4gICAgLy8gPT09PT09PT09PSBUT0RPIDMuMSA9PT09PT09PT09XHJcbiAgICAvLyAxLiBEZWZpbmUgYmlyZFByZWZhYnNcclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBiaXJkUHJlZmFiczogY2MuUHJlZmFiID0gbnVsbDtcclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuaW5pdFByb3BlcnRpZXMoKTtcclxuICAgICAgICB0aGlzLmluaXRSZXNldEJ1dHRvbigpO1xyXG4gICAgICAgIHRoaXMuc2NvcmUgPSAwO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICB1cGRhdGUoKSB7XHJcbiAgICAgICAgdmFyIGRpZmYgPSB0aGlzLmluaXRQb3Muc3ViKHRoaXMubm9kZS5wb3NpdGlvbik7XHJcbiAgICAgICAgdmFyIGFuZ2xlID0gTWF0aC5hdGFuMihkaWZmLngsIGRpZmYueSk7XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS5wb3NpdGlvbi5zdWIodGhpcy5pbml0UG9zKS5tYWcoKSA8PSAxMCkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuZHJhZ2dhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vdG9ySm9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yb3BlSm9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yYi5hbmd1bGFyVmVsb2NpdHkgPSAtYW5nbGUgKiAyMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuYXR0YWNoUm9wZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IxLnNldFBvc2l0aW9uKHRoaXMuaW5pdFBvcy5hZGQoY2MudjIoLTIwLCAwKSkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IyLnNldFBvc2l0aW9uKHRoaXMuaW5pdFBvcy5hZGQoY2MudjIoLTIwLCAwKSkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuYXR0YWNoUm9wZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gLSBjYy5taXNjLnJhZGlhbnNUb0RlZ3JlZXMoYW5nbGUpICsgOTA7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IxLnNldFBvc2l0aW9uKHRoaXMubm9kZS5wb3NpdGlvbi5hZGQoY2MudjIoLTE4LCAyKS5yb3RhdGUoLWFuZ2xlICsgOTApKSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFuY2hvcjIuc2V0UG9zaXRpb24odGhpcy5ub2RlLnBvc2l0aW9uLmFkZChjYy52MigtMTgsIDIpLnJvdGF0ZSgtYW5nbGUgKyA5MCkpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpbml0UHJvcGVydGllcygpIHtcclxuICAgICAgICB0aGlzLmFuY2hvcjEgPSBjYy5maW5kKFwiQ2FudmFzL1NsaW5nc2hvdC9TbGluZ3Nob3RGcm9udC9hbmNob3IxXCIpO1xyXG4gICAgICAgIHRoaXMuYW5jaG9yMS5zZXRQb3NpdGlvbih0aGlzLm5vZGUucG9zaXRpb24uYWRkKGNjLnYyKC0yMCwgMCkpKTtcclxuICAgICAgICB0aGlzLmFuY2hvcjIgPSBjYy5maW5kKFwiQ2FudmFzL1NsaW5nc2hvdC9TbGluZ3Nob3RCYWNrL2FuY2hvcjJcIik7XHJcbiAgICAgICAgdGhpcy5hbmNob3IyLnNldFBvc2l0aW9uKHRoaXMubm9kZS5wb3NpdGlvbi5hZGQoY2MudjIoLTIwLCAwKSkpO1xyXG5cclxuICAgICAgICB0aGlzLm1vdG9ySm9pbnQgPSB0aGlzLmdldENvbXBvbmVudChjYy5Nb3RvckpvaW50KTtcclxuICAgICAgICB0aGlzLnJvcGVKb2ludCA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLlJvcGVKb2ludCk7XHJcbiAgICAgICAgdGhpcy5yYiA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSk7XHJcblxyXG4gICAgICAgIHRoaXMuaW5pdFBvcyA9IHRoaXMubm9kZS5wb3NpdGlvbjtcclxuICAgICAgICB0aGlzLnN0YXJ0UG9zID0gdGhpcy5ub2RlLnBvc2l0aW9uO1xyXG5cclxuICAgICAgICB0aGlzLm1heExlbmd0aCA9IHRoaXMucm9wZUpvaW50Lm1heExlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICBpbml0UmVzZXRCdXR0b24oKSB7XHJcbiAgICAgICAgbGV0IGNsaWNrRXZlbnRIYW5kbGVyID0gbmV3IGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIoKTtcclxuICAgICAgICBjbGlja0V2ZW50SGFuZGxlci50YXJnZXQgPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgY2xpY2tFdmVudEhhbmRsZXIuY29tcG9uZW50ID0gXCJiaXJkXCI7XHJcbiAgICAgICAgY2xpY2tFdmVudEhhbmRsZXIuaGFuZGxlciA9IFwicmVzZXRcIjtcclxuXHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy9SZXNldFwiKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5jbGlja0V2ZW50cy5wdXNoKGNsaWNrRXZlbnRIYW5kbGVyKTtcclxuICAgIH1cclxuXHJcbiAgICByZXNldCgpIHtcclxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24odGhpcy5pbml0UG9zKTtcclxuXHJcbiAgICAgICAgdGhpcy5yYi5saW5lYXJWZWxvY2l0eSA9IGNjLlZlYzIuWkVSTztcclxuICAgICAgICB0aGlzLnJiLmFuZ3VsYXJWZWxvY2l0eSA9IDA7XHJcbiAgICAgICAgdGhpcy5yYi5ncmF2aXR5U2NhbGUgPSAwO1xyXG5cclxuICAgICAgICB0aGlzLm5vZGUuYW5nbGUgPSAwO1xyXG4gICAgICAgIHRoaXMuZHJhZ2dhYmxlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmF0dGFjaFJvcGUgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIG9uRW5hYmxlKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5fb25Ub3VjaEJlZ2FuLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5fb25Ub3VjaE1vdmUsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMuX29uVG91Y2hFbmRlZCwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdGhpcy5fb25Ub3VjaENhbmNlbCwgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgb25EaXNhYmxlKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMuX29uVG91Y2hCZWdhbiwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCB0aGlzLl9vblRvdWNoTW92ZSwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMuX29uVG91Y2hFbmRlZCwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9DQU5DRUwsIHRoaXMuX29uVG91Y2hDYW5jZWwsIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIF9vblRvdWNoQmVnYW4oZXZlbnQpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZW5hYmxlZEluSGllcmFyY2h5KSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmRyYWdnYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLnN0YXJ0UG9zID0gdGhpcy5ub2RlLnBvc2l0aW9uO1xyXG4gICAgICAgICAgICB0aGlzLm1vdG9ySm9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnJiLmdyYXZpdHlTY2FsZSA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMucmIubGluZWFyVmVsb2NpdHkgPSBjYy5WZWMyLlpFUk87XHJcbiAgICAgICAgICAgIHRoaXMucmIuYW5ndWxhclZlbG9jaXR5ID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgX29uVG91Y2hNb3ZlKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWRJbkhpZXJhcmNoeSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5kcmFnZ2FibGUpIHtcclxuICAgICAgICAgICAgbGV0IHN0YXJ0ID0gZXZlbnQuZ2V0U3RhcnRMb2NhdGlvbigpO1xyXG4gICAgICAgICAgICBsZXQgY3VyID0gZXZlbnQuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICAgICAgY3VyLnN1YlNlbGYoc3RhcnQpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGN1cl92ID0gY2MudjIoY3VyLngsIGN1ci55KTtcclxuICAgICAgICAgICAgaWYgKGN1cl92Lm1hZygpID4gdGhpcy5tYXhMZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGN1cl92Lm5vcm1hbGl6ZVNlbGYoKS5tdWxTZWxmKHRoaXMubWF4TGVuZ3RoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKHRoaXMuc3RhcnRQb3MuYWRkKGN1cl92KSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnJiLmxpbmVhclZlbG9jaXR5ID0gY2MuVmVjMi5aRVJPO1xyXG4gICAgICAgICAgICB0aGlzLnJiLmFuZ3VsYXJWZWxvY2l0eSA9IDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBfb25Ub3VjaEVuZGVkKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWRJbkhpZXJhcmNoeSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmRyYWdFbmQoKTtcclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgX29uVG91Y2hDYW5jZWwoZXZlbnQpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZW5hYmxlZEluSGllcmFyY2h5KSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuZHJhZ0VuZCgpO1xyXG5cclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBkcmFnRW5kKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5kcmFnZ2FibGUpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS5wb3NpdGlvbi5zdWIodGhpcy5zdGFydFBvcykubWFnKCkgPiAxMCkge1xyXG4gICAgICAgICAgICB0aGlzLmRyYWdnYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5tb3RvckpvaW50LmVuYWJsZWQgPSB0cnVlO1xyXG5cclxuICAgICAgICB0aGlzLnJiLmdyYXZpdHlTY2FsZSA9IDE7XHJcbiAgICAgICAgdGhpcy5yYi5saW5lYXJWZWxvY2l0eSA9IGNjLnYyKDEsIDApO1xyXG5cclxuICAgICAgICAvLyA9PT09PT09PT09IFRPRE8gMy4zID09PT09PT09PT1cclxuICAgICAgICAvLyAxLiBTcGxpdCB0byB0d28gYmlyZHMgYWZ0ZXIgMC41IHNlYy5cclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3BsaXQoKTtcclxuICAgICAgICB9LCAwLjUpO1xyXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgICAgICB0aGlzLkdhbWVNZ3IucGxheUVmZmVjdCgpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMy4yID09PT09PT09PT1cclxuICAgIC8vIDEuIEluc3RhbnRpYXRlIGFub3RoZXIgYmlyZC5cclxuICAgIC8vIDIuIFNldCB0aGUgbmV3IGJpcmQncyBwb3NpdGlvbiB0byB0aGlzIGJpcmQncyB4IGFuZCB5ICsgMTAuXHJcbiAgICAvLyAzLiBTZXQgdGhlIG5ldyBiaXJkJ3MgbGluZWFyVmVsb2NpdHkgZXF1YWxzIHRvIHRoaXMgYmlyZCdzIHZlbG9jaXR5IHggYW5kIHRoaXMgYmlyZCdzIHZlbG9jaXR5ICh5ICsgNTApLlxyXG4gICAgLy8gNC4gVXNlIGFkZENoaWxkKCkgZnVuY3Rpb24gdG8gcGxhY2UgcHJlZmFiIGludG8gc2NlbmUuXHJcbiAgICAvLyA1LiBEZXN0cm95IHRoZSBzcGxpdCBiaXJkIGFmdGVyIDUgc2Vjb25kcywgaWYgdGhlcmUgZXhpc3QgdGhlIHNtb2tlIGdlbmVyYXRlZCBieSB0aGUgYmlyZCwgYWxzbyBkZXN0cm95IGl0LlxyXG4gICAgc3BsaXQoKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzcGxpdFwiKTtcclxuICAgICAgICB2YXIgYmlyZF9zcGxpdCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYmlyZFByZWZhYnMpO1xyXG4gICAgICAgIGJpcmRfc3BsaXQuc2V0UG9zaXRpb24odGhpcy5ub2RlLnBvc2l0aW9uLngsIHRoaXMubm9kZS5wb3NpdGlvbi55ICsgMTApO1xyXG4gICAgICAgIGJpcmRfc3BsaXQuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52Mih0aGlzLnJiLmxpbmVhclZlbG9jaXR5LngsIHRoaXMucmIubGluZWFyVmVsb2NpdHkueSArIDUwKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL1NsaW5nc2hvdFwiKS5hZGRDaGlsZChiaXJkX3NwbGl0KTtcclxuXHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAoY2MuZmluZChcIkNhbnZhcy9FbnZpcm9ubWVudC9zbW9rZTJcIikpIHtcclxuICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnQvc21va2UyXCIpLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBiaXJkX3NwbGl0LmRlc3Ryb3koKTtcclxuICAgICAgICB9LCA1KTtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbiAgICB1cGRhdGVTY29yZShudW1iZXIpIHtcclxuICAgICAgICB0aGlzLnNjb3JlICs9IG51bWJlcjtcclxuICAgICAgICB0aGlzLnNjb3JlUG9pbnRzLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gdGhpcy5zY29yZS50b1N0cmluZygpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikge1xyXG4gICAgICAgIGlmIChvdGhlci50YWcgPT0gMSkgeyAvLyBlbmVteSB0YWdcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJCZWdpbkNvbnRhY3RcIilcclxuICAgICAgICAgICAgY29uc29sZS5sb2coY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCkucG9pbnRzKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBzbW9rZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuc21va2VQcmVmYWJzKTtcclxuICAgICAgICAgICAgc21va2Uuc2V0UG9zaXRpb24oY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCkucG9pbnRzWzBdKTtcclxuXHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnRcIikuYWRkQ2hpbGQoc21va2UpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBzbW9rZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIH0sIDEuNSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVNjb3JlKDMwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAob3RoZXIudGFnID09IDIpIHsgLy8gZ2FtZSBpdGVtIHRhZ1xyXG5cclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJUcmlnZ2VyXCIpO1xyXG5cclxuICAgICAgICAgICAgb3RoZXIubm9kZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIHRoaXMudXBkYXRlU2NvcmUoMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyA9PT09PT09PT09IFRPRE8gMi4xID09PT09PT09PT1cclxuICAgICAgICAvLyAxLiBJZiBjb250YWN0IHdpdGggYSBzcGlrZSwgcmVzZXQgdGhlIGJpcmQgXHJcbiAgICAgICAgLy8gICAgdG8gdGhlIGluaXRpYWwgcG9zaXRpb24gYWZ0ZXIgMSBzZWNvbmQuXHJcbiAgICAgICAgZWxzZSBpZiAob3RoZXIubm9kZS5uYW1lID09IFwiU3Bpa2VcIikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImh1cnRcIik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICAgICAgfSwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgb25FbmRDb250YWN0KGNvbnRhY3QsIHNlbGYsIG90aGVyKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLnRhZyA9PSAxKSBvdGhlci50YWcgPSAwO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/migration/use_reversed_rotateTo.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ab127XcTXpOGr3ZDAzm1Qj9', 'use_reversed_rotateTo');
// migration/use_reversed_rotateTo.js

"use strict";

/*
 * This script is automatically generated by Cocos Creator and is only used for projects compatible with v2.1.0/v2.1.1/v2.2.1/v2.2.2 versions.
 * You do not need to manually add this script in any other project.
 * If you don't use cc.Action in your project, you can delete this script directly.
 * If your project is hosted in VCS such as git, submit this script together.
 *
 * 此脚本由 Cocos Creator 自动生成，仅用于兼容 v2.1.0/v2.1.1/v2.2.1/v2.2.2 版本的工程，
 * 你无需在任何其它项目中手动添加此脚本。
 * 如果你的项目中没用到 Action，可直接删除该脚本。
 * 如果你的项目有托管于 git 等版本库，请将此脚本一并上传。
 */
cc.RotateTo._reverse = true;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcbWlncmF0aW9uXFx1c2VfcmV2ZXJzZWRfcm90YXRlVG8uanMiXSwibmFtZXMiOlsiY2MiLCJSb3RhdGVUbyIsIl9yZXZlcnNlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxRQUFILENBQVlDLFFBQVosR0FBdUIsSUFBdkIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8qXHJcbiAqIFRoaXMgc2NyaXB0IGlzIGF1dG9tYXRpY2FsbHkgZ2VuZXJhdGVkIGJ5IENvY29zIENyZWF0b3IgYW5kIGlzIG9ubHkgdXNlZCBmb3IgcHJvamVjdHMgY29tcGF0aWJsZSB3aXRoIHYyLjEuMC92Mi4xLjEvdjIuMi4xL3YyLjIuMiB2ZXJzaW9ucy5cclxuICogWW91IGRvIG5vdCBuZWVkIHRvIG1hbnVhbGx5IGFkZCB0aGlzIHNjcmlwdCBpbiBhbnkgb3RoZXIgcHJvamVjdC5cclxuICogSWYgeW91IGRvbid0IHVzZSBjYy5BY3Rpb24gaW4geW91ciBwcm9qZWN0LCB5b3UgY2FuIGRlbGV0ZSB0aGlzIHNjcmlwdCBkaXJlY3RseS5cclxuICogSWYgeW91ciBwcm9qZWN0IGlzIGhvc3RlZCBpbiBWQ1Mgc3VjaCBhcyBnaXQsIHN1Ym1pdCB0aGlzIHNjcmlwdCB0b2dldGhlci5cclxuICpcclxuICog5q2k6ISa5pys55SxIENvY29zIENyZWF0b3Ig6Ieq5Yqo55Sf5oiQ77yM5LuF55So5LqO5YW85a65IHYyLjEuMC92Mi4xLjEvdjIuMi4xL3YyLjIuMiDniYjmnKznmoTlt6XnqIvvvIxcclxuICog5L2g5peg6ZyA5Zyo5Lu75L2V5YW25a6D6aG555uu5Lit5omL5Yqo5re75Yqg5q2k6ISa5pys44CCXHJcbiAqIOWmguaenOS9oOeahOmhueebruS4reayoeeUqOWIsCBBY3Rpb27vvIzlj6/nm7TmjqXliKDpmaTor6XohJrmnKzjgIJcclxuICog5aaC5p6c5L2g55qE6aG555uu5pyJ5omY566h5LqOIGdpdCDnrYnniYjmnKzlupPvvIzor7flsIbmraTohJrmnKzkuIDlubbkuIrkvKDjgIJcclxuICovXHJcblxyXG5jYy5Sb3RhdGVUby5fcmV2ZXJzZSA9IHRydWU7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/menu.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '92efah8QhRHmoYbLlzZWFB7', 'menu');
// Scripts/menu.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var menu = /** @class */ (function (_super) {
    __extends(menu, _super);
    function menu() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    menu.prototype.start = function () {
        var startbtn = new cc.Component.EventHandler();
        startbtn.target = this.node;
        startbtn.component = "menu";
        startbtn.handler = "loadGameScene";
        cc.find("Canvas/StartButton").getComponent(cc.Button).clickEvents.push(startbtn);
    };
    menu.prototype.loadGameScene = function () {
        cc.director.loadScene("main");
    };
    menu = __decorate([
        ccclass
    ], menu);
    return menu;
}(cc.Component));
exports.default = menu;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcbWVudS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBa0Msd0JBQVk7SUFBOUM7O0lBaUJBLENBQUM7SUFiRyxvQkFBSyxHQUFMO1FBQ0ksSUFBSSxRQUFRLEdBQUcsSUFBSSxFQUFFLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQy9DLFFBQVEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUM1QixRQUFRLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQztRQUM1QixRQUFRLENBQUMsT0FBTyxHQUFHLGVBQWUsQ0FBQztRQUVuQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ3JGLENBQUM7SUFFRCw0QkFBYSxHQUFiO1FBQ0ksRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQWZnQixJQUFJO1FBRHhCLE9BQU87T0FDYSxJQUFJLENBaUJ4QjtJQUFELFdBQUM7Q0FqQkQsQUFpQkMsQ0FqQmlDLEVBQUUsQ0FBQyxTQUFTLEdBaUI3QztrQkFqQm9CLElBQUkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIG1lbnUgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuICAgICAgICBsZXQgc3RhcnRidG4gPSBuZXcgY2MuQ29tcG9uZW50LkV2ZW50SGFuZGxlcigpO1xyXG4gICAgICAgIHN0YXJ0YnRuLnRhcmdldCA9IHRoaXMubm9kZTtcclxuICAgICAgICBzdGFydGJ0bi5jb21wb25lbnQgPSBcIm1lbnVcIjtcclxuICAgICAgICBzdGFydGJ0bi5oYW5kbGVyID0gXCJsb2FkR2FtZVNjZW5lXCI7XHJcblxyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvU3RhcnRCdXR0b25cIikuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuY2xpY2tFdmVudHMucHVzaChzdGFydGJ0bik7XHJcbiAgICB9XHJcblxyXG4gICAgbG9hZEdhbWVTY2VuZSgpe1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIm1haW5cIik7XHJcbiAgICB9XHJcbiAgIFxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/splitBirds.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bf68aCPzqtOyIpeTJZUELth', 'splitBirds');
// Scripts/splitBirds.ts

Object.defineProperty(exports, "__esModule", { value: true });
var bird_1 = require("./bird");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var split_bird = /** @class */ (function (_super) {
    __extends(split_bird, _super);
    function split_bird() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.draggable = true;
        _this.attachRope = true;
        _this.smokePrefabs = null;
        // ========== TODO 3.4 ==========
        // 1. Define bird's component.
        _this._bird = null;
        return _this;
    }
    // ==============================
    split_bird.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    // ========== TODO 3.5 ==========
    // 1. Get the bird's component from bird node when instantiated.
    split_bird.prototype.start = function () {
        this._bird = cc.find("Canvas/Slingshot/bird").getComponent(bird_1.bird);
    };
    // ==============================
    split_bird.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact");
            console.log(contact.getWorldManifold().points);
            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);
            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);
            this._bird.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag
            console.log("Trigger");
            other.node.destroy();
            this._bird.updateScore(10);
        }
    };
    split_bird.prototype.onEndContact = function (contact, self, other) {
        if (other.tag == 1)
            other.tag = 0;
    };
    __decorate([
        property(cc.Prefab)
    ], split_bird.prototype, "smokePrefabs", void 0);
    __decorate([
        property(bird_1.bird)
    ], split_bird.prototype, "_bird", void 0);
    split_bird = __decorate([
        ccclass
    ], split_bird);
    return split_bird;
}(cc.Component));
exports.default = split_bird;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcc3BsaXRCaXJkcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0JBQThCO0FBRXhCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBeUVDO1FBcEVHLGVBQVMsR0FBWSxJQUFJLENBQUM7UUFDMUIsZ0JBQVUsR0FBWSxJQUFJLENBQUM7UUFhM0Isa0JBQVksR0FBYyxJQUFJLENBQUM7UUFFL0IsaUNBQWlDO1FBQ2pDLDhCQUE4QjtRQUU5QixXQUFLLEdBQVMsSUFBSSxDQUFDOztJQWlEdkIsQ0FBQztJQWhERyxpQ0FBaUM7SUFHakMsMkJBQU0sR0FBTjtRQUNJLEVBQUUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO0lBQ25ELENBQUM7SUFFRCxpQ0FBaUM7SUFDakMsZ0VBQWdFO0lBQ2hFLDBCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBSSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUNELGlDQUFpQztJQUdqQyxtQ0FBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQy9CLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxZQUFZO1lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUE7WUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUvQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM5QyxLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhELEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDZCxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRVIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDOUI7YUFDSSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCO1lBRXZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFdkIsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFJRCxpQ0FBWSxHQUFaLFVBQWEsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQzdCLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQUUsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQWpERDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO29EQUNXO0lBSy9CO1FBREMsUUFBUSxDQUFDLFdBQUksQ0FBQzs2Q0FDSTtJQXhCRixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBeUU5QjtJQUFELGlCQUFDO0NBekVELEFBeUVDLENBekV1QyxFQUFFLENBQUMsU0FBUyxHQXlFbkQ7a0JBekVvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYmlyZCB9IGZyb20gXCIuL2JpcmRcIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBzcGxpdF9iaXJkIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBhbmNob3IxOiBjYy5Ob2RlO1xyXG4gICAgYW5jaG9yMjogY2MuTm9kZTtcclxuXHJcbiAgICBkcmFnZ2FibGU6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgYXR0YWNoUm9wZTogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgaW5pdFBvczogY2MuVmVjMjtcclxuICAgIHN0YXJ0UG9zOiBjYy5WZWMyO1xyXG5cclxuICAgIG1vdG9ySm9pbnQ6IGNjLk1vdG9ySm9pbnQ7XHJcbiAgICByb3BlSm9pbnQ6IGNjLlJvcGVKb2ludDtcclxuICAgIHJiOiBjYy5SaWdpZEJvZHk7XHJcblxyXG4gICAgbWF4TGVuZ3RoOiBudW1iZXI7XHJcblxyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBzbW9rZVByZWZhYnM6IGNjLlByZWZhYiA9IG51bGw7XHJcblxyXG4gICAgLy8gPT09PT09PT09PSBUT0RPIDMuNCA9PT09PT09PT09XHJcbiAgICAvLyAxLiBEZWZpbmUgYmlyZCdzIGNvbXBvbmVudC5cclxuICAgIEBwcm9wZXJ0eShiaXJkKVxyXG4gICAgX2JpcmQ6IGJpcmQgPSBudWxsO1xyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT0gVE9ETyAzLjUgPT09PT09PT09PVxyXG4gICAgLy8gMS4gR2V0IHRoZSBiaXJkJ3MgY29tcG9uZW50IGZyb20gYmlyZCBub2RlIHdoZW4gaW5zdGFudGlhdGVkLlxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgdGhpcy5fYmlyZCA9IGNjLmZpbmQoXCJDYW52YXMvU2xpbmdzaG90L2JpcmRcIikuZ2V0Q29tcG9uZW50KGJpcmQpO1xyXG4gICAgfVxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5cclxuICAgIG9uQmVnaW5Db250YWN0KGNvbnRhY3QsIHNlbGYsIG90aGVyKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLnRhZyA9PSAxKSB7IC8vIGVuZW15IHRhZ1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkJlZ2luQ29udGFjdFwiKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjb250YWN0LmdldFdvcmxkTWFuaWZvbGQoKS5wb2ludHMpO1xyXG5cclxuICAgICAgICAgICAgdmFyIHNtb2tlID0gY2MuaW5zdGFudGlhdGUodGhpcy5zbW9rZVByZWZhYnMpO1xyXG4gICAgICAgICAgICBzbW9rZS5zZXRQb3NpdGlvbihjb250YWN0LmdldFdvcmxkTWFuaWZvbGQoKS5wb2ludHNbMF0pO1xyXG5cclxuICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9FbnZpcm9ubWVudFwiKS5hZGRDaGlsZChzbW9rZSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHNtb2tlLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgfSwgMS41KTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2JpcmQudXBkYXRlU2NvcmUoMzApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChvdGhlci50YWcgPT0gMikgeyAvLyBnYW1lIGl0ZW0gdGFnXHJcblxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRyaWdnZXJcIik7XHJcblxyXG4gICAgICAgICAgICBvdGhlci5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgdGhpcy5fYmlyZC51cGRhdGVTY29yZSgxMCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgb25FbmRDb250YWN0KGNvbnRhY3QsIHNlbGYsIG90aGVyKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLnRhZyA9PSAxKSBvdGhlci50YWcgPSAwO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/GameManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db5ccu2mJpFE6gK1j6VIz8U', 'GameManager');
// Scripts/GameManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.GameManager = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManager = /** @class */ (function (_super) {
    __extends(GameManager, _super);
    function GameManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bgm = null;
        _this.flyingSE = null;
        _this.pigsmPrefabs = null;
        _this.pigbgPrefabs = null;
        return _this;
    }
    GameManager.prototype.start = function () {
        this.playBGM();
        this.pigInstantiate();
    };
    GameManager.prototype.playBGM = function () {
        cc.audioEngine.playMusic(this.bgm, true);
    };
    GameManager.prototype.playEffect = function () {
        cc.audioEngine.playEffect(this.flyingSE, false);
    };
    GameManager.prototype.pigInstantiate = function () {
        var pig_sm = cc.instantiate(this.pigsmPrefabs);
        pig_sm.setPosition(822.711, 240.513);
        cc.find("Canvas/Environment").addChild(pig_sm);
        var pig_bg = cc.instantiate(this.pigbgPrefabs);
        pig_bg.setPosition(822.711, 335.628);
        cc.find("Canvas/Environment").addChild(pig_bg);
    };
    __decorate([
        property(cc.AudioClip)
    ], GameManager.prototype, "bgm", void 0);
    __decorate([
        property(cc.AudioClip)
    ], GameManager.prototype, "flyingSE", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "pigsmPrefabs", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "pigbgPrefabs", void 0);
    GameManager = __decorate([
        ccclass
    ], GameManager);
    return GameManager;
}(cc.Component));
exports.GameManager = GameManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcR2FtZU1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFpQywrQkFBWTtJQUE3QztRQUFBLHFFQXdDQztRQXJDRyxTQUFHLEdBQWlCLElBQUksQ0FBQztRQUd6QixjQUFRLEdBQWlCLElBQUksQ0FBQztRQUk5QixrQkFBWSxHQUFjLElBQUksQ0FBQztRQUcvQixrQkFBWSxHQUFjLElBQUksQ0FBQzs7SUEyQm5DLENBQUM7SUF4QkcsMkJBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsNkJBQU8sR0FBUDtRQUNJLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELGdDQUFVLEdBQVY7UUFDSSxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxvQ0FBYyxHQUFkO1FBRUksSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDL0MsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckMsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUvQyxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMvQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNyQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFuQ0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQzs0Q0FDRTtJQUd6QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDO2lEQUNPO0lBSTlCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7cURBQ1c7SUFHL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztxREFDVztJQWJ0QixXQUFXO1FBRHZCLE9BQU87T0FDSyxXQUFXLENBd0N2QjtJQUFELGtCQUFDO0NBeENELEFBd0NDLENBeENnQyxFQUFFLENBQUMsU0FBUyxHQXdDNUM7QUF4Q1ksa0NBQVciLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGNsYXNzIEdhbWVNYW5hZ2VyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuQXVkaW9DbGlwKVxyXG4gICAgYmdtOiBjYy5BdWRpb0NsaXAgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5BdWRpb0NsaXApXHJcbiAgICBmbHlpbmdTRTogY2MuQXVkaW9DbGlwID0gbnVsbDtcclxuXHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHBpZ3NtUHJlZmFiczogY2MuUHJlZmFiID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxyXG4gICAgcGlnYmdQcmVmYWJzOiBjYy5QcmVmYWIgPSBudWxsO1xyXG5cclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnBsYXlCR00oKTtcclxuICAgICAgICB0aGlzLnBpZ0luc3RhbnRpYXRlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcGxheUJHTSgpe1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlNdXNpYyh0aGlzLmJnbSwgdHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcGxheUVmZmVjdCgpe1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5mbHlpbmdTRSwgZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHBpZ0luc3RhbnRpYXRlKCkge1xyXG5cclxuICAgICAgICB2YXIgcGlnX3NtID0gY2MuaW5zdGFudGlhdGUodGhpcy5waWdzbVByZWZhYnMpO1xyXG4gICAgICAgIHBpZ19zbS5zZXRQb3NpdGlvbig4MjIuNzExLCAyNDAuNTEzKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL0Vudmlyb25tZW50XCIpLmFkZENoaWxkKHBpZ19zbSk7XHJcblxyXG4gICAgICAgIHZhciBwaWdfYmcgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBpZ2JnUHJlZmFicyk7XHJcbiAgICAgICAgcGlnX2JnLnNldFBvc2l0aW9uKDgyMi43MTEsIDMzNS42MjgpO1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnRcIikuYWRkQ2hpbGQocGlnX2JnKTtcclxuICAgIH1cclxuXHJcbn1cclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/platform.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a1c2a1ZYJNBFqNVdhAnBXFr', 'platform');
// Scripts/platform.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Platform = /** @class */ (function (_super) {
    __extends(Platform, _super);
    function Platform() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Vertical_platform = null;
        _this.Horizontal_platform = null;
        _this.Vertical_spike = null;
        _this.Horizontal_spike = null;
        return _this;
    }
    // ========== TODO 1.2 ==========
    // 1. Let platforms continue to move during the game.
    Platform.prototype.start = function () {
        this.platformMove("vertical", 1, this.Vertical_platform);
        this.platformMove("horizontal", 1, this.Horizontal_platform);
        // ========= TODO 1.3.1 =========
        // 1. Let the vertical spike move 
        this.spikeMove(1, this.Vertical_spike);
        // ==============================
    };
    // ==============================
    // ========= TODO 1.3.2 =========
    // 1. Let the horizontal spike always stay at the initial local position,
    //    So, it will move with its parent correctly
    Platform.prototype.update = function () {
        this.Horizontal_spike.setPosition(0, 30);
    };
    // ==============================
    // ========== TODO 1.1 ==========
    // 1. Define the action sequence.
    //    (Hint: you can use cc.sequence and cc.easeInOut to help you design actions.)
    // 2. Use moveDir to decide whether you should move vertical or horizontal.
    // 3. Let a variable action represent the "repeated action".
    //    (Hint: cc.repeatForever)
    // 4. Use schedule function to set the delay time when game start.
    Platform.prototype.platformMove = function (moveDir, delayTime, platform) {
        var action;
        var easeRate = 2;
        var sequence1 = cc.sequence(cc.moveBy(2, 0, 120).easing(cc.easeInOut(easeRate)), cc.moveBy(2, 0, -120).easing(cc.easeInOut(easeRate)));
        var sequence2 = cc.sequence(cc.moveBy(2, 120, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(2, -120, 0).easing(cc.easeInOut(easeRate)));
        if (moveDir == "vertical") {
            action = cc.repeatForever(sequence1);
        }
        else {
            action = cc.repeatForever(sequence2);
        }
        this.scheduleOnce(function () {
            platform.runAction(action);
        }, delayTime);
    };
    // ==============================
    Platform.prototype.spikeMove = function (delayTime, spike) {
        var action;
        var easeRate = 2;
        var sequence = cc.sequence(cc.moveBy(1, 40, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(1, -40, 0).easing(cc.easeInOut(easeRate)));
        action = cc.repeatForever(sequence);
        this.scheduleOnce(function () {
            spike.runAction(action);
        }, delayTime);
    };
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Vertical_platform", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Horizontal_platform", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Vertical_spike", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Horizontal_spike", void 0);
    Platform = __decorate([
        ccclass
    ], Platform);
    return Platform;
}(cc.Component));
exports.default = Platform;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xccGxhdGZvcm0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXNDLDRCQUFZO0lBQWxEO1FBQUEscUVBc0VDO1FBbkVHLHVCQUFpQixHQUFZLElBQUksQ0FBQztRQUdsQyx5QkFBbUIsR0FBWSxJQUFJLENBQUM7UUFHcEMsb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFHL0Isc0JBQWdCLEdBQVksSUFBSSxDQUFDOztJQTBEckMsQ0FBQztJQXhERyxpQ0FBaUM7SUFDakMscURBQXFEO0lBQ3JELHdCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQzdELGlDQUFpQztRQUNqQyxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3ZDLGlDQUFpQztJQUNyQyxDQUFDO0lBQ0QsaUNBQWlDO0lBRWpDLGlDQUFpQztJQUNqQyx5RUFBeUU7SUFDekUsZ0RBQWdEO0lBQ2hELHlCQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsaUNBQWlDO0lBR2pDLGlDQUFpQztJQUNqQyxpQ0FBaUM7SUFDakMsa0ZBQWtGO0lBQ2xGLDJFQUEyRTtJQUMzRSw0REFBNEQ7SUFDNUQsOEJBQThCO0lBQzlCLGtFQUFrRTtJQUNsRSwrQkFBWSxHQUFaLFVBQWEsT0FBZSxFQUFFLFNBQWlCLEVBQUUsUUFBaUI7UUFDOUQsSUFBSSxNQUFpQixDQUFDO1FBQ3RCLElBQUksUUFBUSxHQUFXLENBQUMsQ0FBQztRQUN6QixJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SSxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SSxJQUFJLE9BQU8sSUFBSSxVQUFVLEVBQUU7WUFDdkIsTUFBTSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDeEM7YUFDSTtZQUNELE1BQU0sR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ3hDO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ2xCLENBQUM7SUFDRCxpQ0FBaUM7SUFHakMsNEJBQVMsR0FBVCxVQUFVLFNBQWlCLEVBQUUsS0FBYztRQUN2QyxJQUFJLE1BQWlCLENBQUM7UUFDdEIsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BJLE1BQU0sR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDZCxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVCLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUNsQixDQUFDO0lBakVEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7dURBQ2dCO0lBR2xDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7eURBQ2tCO0lBR3BDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7b0RBQ2E7SUFHL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztzREFDZTtJQVpoQixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBc0U1QjtJQUFELGVBQUM7Q0F0RUQsQUFzRUMsQ0F0RXFDLEVBQUUsQ0FBQyxTQUFTLEdBc0VqRDtrQkF0RW9CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGxhdGZvcm0gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgVmVydGljYWxfcGxhdGZvcm06IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgSG9yaXpvbnRhbF9wbGF0Zm9ybTogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBWZXJ0aWNhbF9zcGlrZTogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBIb3Jpem9udGFsX3NwaWtlOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMS4yID09PT09PT09PT1cclxuICAgIC8vIDEuIExldCBwbGF0Zm9ybXMgY29udGludWUgdG8gbW92ZSBkdXJpbmcgdGhlIGdhbWUuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnBsYXRmb3JtTW92ZShcInZlcnRpY2FsXCIsIDEsIHRoaXMuVmVydGljYWxfcGxhdGZvcm0pO1xyXG4gICAgICAgIHRoaXMucGxhdGZvcm1Nb3ZlKFwiaG9yaXpvbnRhbFwiLCAxLCB0aGlzLkhvcml6b250YWxfcGxhdGZvcm0pO1xyXG4gICAgICAgIC8vID09PT09PT09PSBUT0RPIDEuMy4xID09PT09PT09PVxyXG4gICAgICAgIC8vIDEuIExldCB0aGUgdmVydGljYWwgc3Bpa2UgbW92ZSBcclxuICAgICAgICB0aGlzLnNwaWtlTW92ZSgxLCB0aGlzLlZlcnRpY2FsX3NwaWtlKTtcclxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8vID09PT09PT09PSBUT0RPIDEuMy4yID09PT09PT09PVxyXG4gICAgLy8gMS4gTGV0IHRoZSBob3Jpem9udGFsIHNwaWtlIGFsd2F5cyBzdGF5IGF0IHRoZSBpbml0aWFsIGxvY2FsIHBvc2l0aW9uLFxyXG4gICAgLy8gICAgU28sIGl0IHdpbGwgbW92ZSB3aXRoIGl0cyBwYXJlbnQgY29ycmVjdGx5XHJcbiAgICB1cGRhdGUoKSB7XHJcbiAgICAgICAgdGhpcy5Ib3Jpem9udGFsX3NwaWtlLnNldFBvc2l0aW9uKDAsIDMwKTtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMS4xID09PT09PT09PT1cclxuICAgIC8vIDEuIERlZmluZSB0aGUgYWN0aW9uIHNlcXVlbmNlLlxyXG4gICAgLy8gICAgKEhpbnQ6IHlvdSBjYW4gdXNlIGNjLnNlcXVlbmNlIGFuZCBjYy5lYXNlSW5PdXQgdG8gaGVscCB5b3UgZGVzaWduIGFjdGlvbnMuKVxyXG4gICAgLy8gMi4gVXNlIG1vdmVEaXIgdG8gZGVjaWRlIHdoZXRoZXIgeW91IHNob3VsZCBtb3ZlIHZlcnRpY2FsIG9yIGhvcml6b250YWwuXHJcbiAgICAvLyAzLiBMZXQgYSB2YXJpYWJsZSBhY3Rpb24gcmVwcmVzZW50IHRoZSBcInJlcGVhdGVkIGFjdGlvblwiLlxyXG4gICAgLy8gICAgKEhpbnQ6IGNjLnJlcGVhdEZvcmV2ZXIpXHJcbiAgICAvLyA0LiBVc2Ugc2NoZWR1bGUgZnVuY3Rpb24gdG8gc2V0IHRoZSBkZWxheSB0aW1lIHdoZW4gZ2FtZSBzdGFydC5cclxuICAgIHBsYXRmb3JtTW92ZShtb3ZlRGlyOiBzdHJpbmcsIGRlbGF5VGltZTogbnVtYmVyLCBwbGF0Zm9ybTogY2MuTm9kZSkge1xyXG4gICAgICAgIGxldCBhY3Rpb246IGNjLkFjdGlvbjtcclxuICAgICAgICBsZXQgZWFzZVJhdGU6IG51bWJlciA9IDI7XHJcbiAgICAgICAgdmFyIHNlcXVlbmNlMSA9IGNjLnNlcXVlbmNlKGNjLm1vdmVCeSgyLCAwLCAxMjApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSwgY2MubW92ZUJ5KDIsIDAsIC0xMjApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSk7XHJcbiAgICAgICAgdmFyIHNlcXVlbmNlMiA9IGNjLnNlcXVlbmNlKGNjLm1vdmVCeSgyLCAxMjAsIDApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSwgY2MubW92ZUJ5KDIsIC0xMjAsIDApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSk7XHJcbiAgICAgICAgaWYgKG1vdmVEaXIgPT0gXCJ2ZXJ0aWNhbFwiKSB7XHJcbiAgICAgICAgICAgIGFjdGlvbiA9IGNjLnJlcGVhdEZvcmV2ZXIoc2VxdWVuY2UxKTtcclxuICAgICAgICB9IFxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBhY3Rpb24gPSBjYy5yZXBlYXRGb3JldmVyKHNlcXVlbmNlMik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcGxhdGZvcm0ucnVuQWN0aW9uKGFjdGlvbik7XHJcbiAgICAgICAgfSwgZGVsYXlUaW1lKTtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbiAgICBzcGlrZU1vdmUoZGVsYXlUaW1lOiBudW1iZXIsIHNwaWtlOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgbGV0IGFjdGlvbjogY2MuQWN0aW9uO1xyXG4gICAgICAgIGxldCBlYXNlUmF0ZTogbnVtYmVyID0gMjtcclxuICAgICAgICB2YXIgc2VxdWVuY2UgPSBjYy5zZXF1ZW5jZShjYy5tb3ZlQnkoMSwgNDAsIDApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSwgY2MubW92ZUJ5KDEsIC00MCwgMCkuZWFzaW5nKGNjLmVhc2VJbk91dChlYXNlUmF0ZSkpKTtcclxuICAgICAgICBhY3Rpb24gPSBjYy5yZXBlYXRGb3JldmVyKHNlcXVlbmNlKTtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHNwaWtlLnJ1bkFjdGlvbihhY3Rpb24pO1xyXG4gICAgICAgIH0sIGRlbGF5VGltZSk7XHJcbiAgICB9XHJcblxyXG59Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/anchor.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '71751osmgNCQJK7nodKEKDx', 'anchor');
// Scripts/anchor.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var anchor = /** @class */ (function (_super) {
    __extends(anchor, _super);
    function anchor() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = _this.node;
        return _this;
    }
    anchor.prototype.start = function () {
        this.graphics = this.node.getComponent(cc.Graphics);
    };
    anchor.prototype.lateUpdate = function () {
        this.graphics.clear();
        this.graphics.moveTo(0, 0);
        var offset = this.target.position.sub(this.node.position);
        this.graphics.lineTo(offset.x, offset.y);
        this.graphics.stroke();
    };
    __decorate([
        property(cc.Node)
    ], anchor.prototype, "target", void 0);
    anchor = __decorate([
        ccclass
    ], anchor);
    return anchor;
}(cc.Component));
exports.default = anchor;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcYW5jaG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUFvQywwQkFBWTtJQUFoRDtRQUFBLHFFQXFCQztRQWxCRyxZQUFNLEdBQVksS0FBSSxDQUFDLElBQUksQ0FBQzs7SUFrQmhDLENBQUM7SUFkRyxzQkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELDJCQUFVLEdBQVY7UUFDSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUUzQixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFqQkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzswQ0FDVTtJQUhYLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FxQjFCO0lBQUQsYUFBQztDQXJCRCxBQXFCQyxDQXJCbUMsRUFBRSxDQUFDLFNBQVMsR0FxQi9DO2tCQXJCb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgYW5jaG9yIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHRhcmdldDogY2MuTm9kZSA9IHRoaXMubm9kZTtcclxuXHJcbiAgICBncmFwaGljczogY2MuR3JhcGhpY3M7XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcclxuICAgIH1cclxuXHJcbiAgICBsYXRlVXBkYXRlICgpIHtcclxuICAgICAgICB0aGlzLmdyYXBoaWNzLmNsZWFyKCk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MubW92ZVRvKDAsIDApO1xyXG5cclxuICAgICAgICBsZXQgb2Zmc2V0ID0gdGhpcy50YXJnZXQucG9zaXRpb24uc3ViKHRoaXMubm9kZS5wb3NpdGlvbik7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MubGluZVRvKG9mZnNldC54LCBvZmZzZXQueSk7XHJcbiAgICAgICAgdGhpcy5ncmFwaGljcy5zdHJva2UoKTtcclxuICAgIH1cclxufVxyXG4iXX0=
//------QC-SOURCE-SPLIT------
