
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/anchor.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '71751osmgNCQJK7nodKEKDx', 'anchor');
// Scripts/anchor.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var anchor = /** @class */ (function (_super) {
    __extends(anchor, _super);
    function anchor() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = _this.node;
        return _this;
    }
    anchor.prototype.start = function () {
        this.graphics = this.node.getComponent(cc.Graphics);
    };
    anchor.prototype.lateUpdate = function () {
        this.graphics.clear();
        this.graphics.moveTo(0, 0);
        var offset = this.target.position.sub(this.node.position);
        this.graphics.lineTo(offset.x, offset.y);
        this.graphics.stroke();
    };
    __decorate([
        property(cc.Node)
    ], anchor.prototype, "target", void 0);
    anchor = __decorate([
        ccclass
    ], anchor);
    return anchor;
}(cc.Component));
exports.default = anchor;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcYW5jaG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXNCLEVBQUUsQ0FBQyxVQUFVLEVBQWxDLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBaUIsQ0FBQztBQUcxQztJQUFvQywwQkFBWTtJQUFoRDtRQUFBLHFFQXFCQztRQWxCRyxZQUFNLEdBQVksS0FBSSxDQUFDLElBQUksQ0FBQzs7SUFrQmhDLENBQUM7SUFkRyxzQkFBSyxHQUFMO1FBQ0ksSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVELDJCQUFVLEdBQVY7UUFDSSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXRCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUUzQixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFqQkQ7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzswQ0FDVTtJQUhYLE1BQU07UUFEMUIsT0FBTztPQUNhLE1BQU0sQ0FxQjFCO0lBQUQsYUFBQztDQXJCRCxBQXFCQyxDQXJCbUMsRUFBRSxDQUFDLFNBQVMsR0FxQi9DO2tCQXJCb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgYW5jaG9yIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHRhcmdldDogY2MuTm9kZSA9IHRoaXMubm9kZTtcclxuXHJcbiAgICBncmFwaGljczogY2MuR3JhcGhpY3M7XHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcclxuICAgIH1cclxuXHJcbiAgICBsYXRlVXBkYXRlICgpIHtcclxuICAgICAgICB0aGlzLmdyYXBoaWNzLmNsZWFyKCk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MubW92ZVRvKDAsIDApO1xyXG5cclxuICAgICAgICBsZXQgb2Zmc2V0ID0gdGhpcy50YXJnZXQucG9zaXRpb24uc3ViKHRoaXMubm9kZS5wb3NpdGlvbik7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MubGluZVRvKG9mZnNldC54LCBvZmZzZXQueSk7XHJcbiAgICAgICAgdGhpcy5ncmFwaGljcy5zdHJva2UoKTtcclxuICAgIH1cclxufVxyXG4iXX0=