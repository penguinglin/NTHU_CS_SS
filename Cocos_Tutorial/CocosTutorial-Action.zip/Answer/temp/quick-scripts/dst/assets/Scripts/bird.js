
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/bird.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6d012QIyy5FOLpzct9wIDzm', 'bird');
// Scripts/bird.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.bird = void 0;
var GameManager_1 = require("./GameManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var bird = /** @class */ (function (_super) {
    __extends(bird, _super);
    function bird() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.draggable = true;
        _this.attachRope = true;
        _this.scorePoints = null;
        _this.smokePrefabs = null;
        _this.GameMgr = null;
        // ========== TODO 3.1 ==========
        // 1. Define birdPrefabs
        _this.birdPrefabs = null;
        return _this;
    }
    // ==============================
    bird.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    bird.prototype.start = function () {
        this.initProperties();
        this.initResetButton();
        this.score = 0;
    };
    bird.prototype.update = function () {
        var diff = this.initPos.sub(this.node.position);
        var angle = Math.atan2(diff.x, diff.y);
        if (this.node.position.sub(this.initPos).mag() <= 10) {
            if (!this.draggable) {
                this.motorJoint.enabled = false;
                this.ropeJoint.enabled = false;
                this.rb.angularVelocity = -angle * 20;
                this.attachRope = false;
                this.anchor1.setPosition(this.initPos.add(cc.v2(-20, 0)));
                this.anchor2.setPosition(this.initPos.add(cc.v2(-20, 0)));
            }
        }
        else {
            if (this.attachRope) {
                this.node.angle = -cc.misc.radiansToDegrees(angle) + 90;
                this.anchor1.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
                this.anchor2.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
            }
        }
    };
    bird.prototype.initProperties = function () {
        this.anchor1 = cc.find("Canvas/Slingshot/SlingshotFront/anchor1");
        this.anchor1.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.anchor2 = cc.find("Canvas/Slingshot/SlingshotBack/anchor2");
        this.anchor2.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.motorJoint = this.getComponent(cc.MotorJoint);
        this.ropeJoint = this.getComponent(cc.RopeJoint);
        this.rb = this.getComponent(cc.RigidBody);
        this.initPos = this.node.position;
        this.startPos = this.node.position;
        this.maxLength = this.ropeJoint.maxLength;
    };
    bird.prototype.initResetButton = function () {
        var clickEventHandler = new cc.Component.EventHandler();
        clickEventHandler.target = this.node;
        clickEventHandler.component = "bird";
        clickEventHandler.handler = "reset";
        cc.find("Canvas/Reset").getComponent(cc.Button).clickEvents.push(clickEventHandler);
    };
    bird.prototype.reset = function () {
        this.node.setPosition(this.initPos);
        this.rb.linearVelocity = cc.Vec2.ZERO;
        this.rb.angularVelocity = 0;
        this.rb.gravityScale = 0;
        this.node.angle = 0;
        this.draggable = true;
        this.attachRope = true;
    };
    bird.prototype.onEnable = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    };
    bird.prototype.onDisable = function () {
        this.node.off(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    };
    bird.prototype._onTouchBegan = function (event) {
        if (!this.enabledInHierarchy)
            return;
        if (this.draggable) {
            this.startPos = this.node.position;
            this.motorJoint.enabled = false;
            this.rb.gravityScale = 0;
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    };
    bird.prototype._onTouchMove = function (event) {
        if (!this.enabledInHierarchy)
            return;
        if (this.draggable) {
            var start = event.getStartLocation();
            var cur = event.getLocation();
            cur.subSelf(start);
            var cur_v = cc.v2(cur.x, cur.y);
            if (cur_v.mag() > this.maxLength) {
                cur_v.normalizeSelf().mulSelf(this.maxLength);
            }
            this.node.setPosition(this.startPos.add(cur_v));
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    };
    bird.prototype._onTouchEnded = function (event) {
        if (!this.enabledInHierarchy)
            return;
        this.dragEnd();
        event.stopPropagation();
    };
    bird.prototype._onTouchCancel = function (event) {
        if (!this.enabledInHierarchy)
            return;
        this.dragEnd();
        event.stopPropagation();
    };
    bird.prototype.dragEnd = function () {
        if (!this.draggable)
            return;
        if (this.node.position.sub(this.startPos).mag() > 10) {
            this.draggable = false;
        }
        this.motorJoint.enabled = true;
        this.rb.gravityScale = 1;
        this.rb.linearVelocity = cc.v2(1, 0);
        // ========== TODO 3.3 ==========
        // 1. Split to two birds after 0.5 sec.
        this.scheduleOnce(function () {
            this.split();
        }, 0.5);
        // ==============================
        this.GameMgr.playEffect();
    };
    // ========== TODO 3.2 ==========
    // 1. Instantiate another bird.
    // 2. Set the new bird's position to this bird's x and y + 10.
    // 3. Set the new bird's linearVelocity equals to this bird's velocity x and this bird's velocity (y + 50).
    // 4. Use addChild() function to place prefab into scene.
    // 5. Destroy the split bird after 5 seconds, if there exist the smoke generated by the bird, also destroy it.
    bird.prototype.split = function () {
        console.log("split");
        var bird_split = cc.instantiate(this.birdPrefabs);
        bird_split.setPosition(this.node.position.x, this.node.position.y + 10);
        bird_split.getComponent(cc.RigidBody).linearVelocity = cc.v2(this.rb.linearVelocity.x, this.rb.linearVelocity.y + 50);
        cc.find("Canvas/Slingshot").addChild(bird_split);
        this.scheduleOnce(function () {
            if (cc.find("Canvas/Environment/smoke2")) {
                cc.find("Canvas/Environment/smoke2").destroy();
            }
            bird_split.destroy();
        }, 5);
    };
    // ==============================
    bird.prototype.updateScore = function (number) {
        this.score += number;
        this.scorePoints.getComponent(cc.Label).string = this.score.toString();
    };
    bird.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact");
            console.log(contact.getWorldManifold().points);
            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);
            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);
            this.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag
            console.log("Trigger");
            other.node.destroy();
            this.updateScore(10);
        }
        // ========== TODO 2.1 ==========
        // 1. If contact with a spike, reset the bird 
        //    to the initial position after 1 second.
        else if (other.node.name == "Spike") {
            console.log("hurt");
            this.scheduleOnce(function () {
                this.reset();
            }, 1);
        }
        // ==============================
    };
    bird.prototype.onEndContact = function (contact, self, other) {
        if (other.tag == 1)
            other.tag = 0;
    };
    __decorate([
        property(cc.Node)
    ], bird.prototype, "scorePoints", void 0);
    __decorate([
        property(cc.Prefab)
    ], bird.prototype, "smokePrefabs", void 0);
    __decorate([
        property(GameManager_1.GameManager)
    ], bird.prototype, "GameMgr", void 0);
    __decorate([
        property(cc.Prefab)
    ], bird.prototype, "birdPrefabs", void 0);
    bird = __decorate([
        ccclass
    ], bird);
    return bird;
}(cc.Component));
exports.bird = bird;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcYmlyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZDQUE0QztBQUV0QyxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUEwQix3QkFBWTtJQUF0QztRQUFBLHFFQW9RQztRQS9QRyxlQUFTLEdBQVksSUFBSSxDQUFDO1FBQzFCLGdCQUFVLEdBQVksSUFBSSxDQUFDO1FBYzNCLGlCQUFXLEdBQUcsSUFBSSxDQUFDO1FBR25CLGtCQUFZLEdBQWMsSUFBSSxDQUFDO1FBRy9CLGFBQU8sR0FBZ0IsSUFBSSxDQUFDO1FBRTVCLGlDQUFpQztRQUNqQyx3QkFBd0I7UUFFeEIsaUJBQVcsR0FBYyxJQUFJLENBQUM7O0lBcU9sQyxDQUFDO0lBcE9HLGlDQUFpQztJQUVqQyxxQkFBTSxHQUFOO1FBQ0ksRUFBRSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7SUFDbkQsQ0FBQztJQUVELG9CQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQ25CLENBQUM7SUFHRCxxQkFBTSxHQUFOO1FBQ0ksSUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNoRCxJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDbEQsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztnQkFDaEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2dCQUMvQixJQUFJLENBQUMsRUFBRSxDQUFDLGVBQWUsR0FBRyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dCQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDN0Q7U0FDSjthQUFNO1lBQ0gsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUV6RCxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3ZGO1NBQ0o7SUFDTCxDQUFDO0lBRUQsNkJBQWMsR0FBZDtRQUNJLElBQUksQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsd0NBQXdDLENBQUMsQ0FBQztRQUNqRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEUsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7UUFFMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUNsQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBRW5DLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7SUFDOUMsQ0FBQztJQUVELDhCQUFlLEdBQWY7UUFDSSxJQUFJLGlCQUFpQixHQUFHLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN4RCxpQkFBaUIsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNyQyxpQkFBaUIsQ0FBQyxTQUFTLEdBQUcsTUFBTSxDQUFDO1FBQ3JDLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFFcEMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUN4RixDQUFDO0lBRUQsb0JBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVwQyxJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUN0QyxJQUFJLENBQUMsRUFBRSxDQUFDLGVBQWUsR0FBRyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNwQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztJQUMzQixDQUFDO0lBRUQsdUJBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFRCx3QkFBUyxHQUFUO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUVELDRCQUFhLEdBQWIsVUFBYyxLQUFLO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0I7WUFBRSxPQUFPO1FBRXJDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztZQUNoQyxJQUFJLENBQUMsRUFBRSxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUM7WUFDekIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1NBQy9CO1FBQ0QsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCwyQkFBWSxHQUFaLFVBQWEsS0FBSztRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDckMsSUFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzlCLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFbkIsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNoQyxJQUFJLEtBQUssQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUM5QixLQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUNqRDtZQUVELElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFFaEQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDdEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1NBQy9CO1FBRUQsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCw0QkFBYSxHQUFiLFVBQWMsS0FBSztRQUNmLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFZixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELDZCQUFjLEdBQWQsVUFBZSxLQUFLO1FBQ2hCLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFFZixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELHNCQUFPLEdBQVA7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVM7WUFBRSxPQUFPO1FBRTVCLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDbEQsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7U0FDMUI7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFL0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRXJDLGlDQUFpQztRQUNqQyx1Q0FBdUM7UUFDdkMsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNqQixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDUixpQ0FBaUM7UUFFakMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUU5QixDQUFDO0lBRUQsaUNBQWlDO0lBQ2pDLCtCQUErQjtJQUMvQiw4REFBOEQ7SUFDOUQsMkdBQTJHO0lBQzNHLHlEQUF5RDtJQUN6RCw4R0FBOEc7SUFDOUcsb0JBQUssR0FBTDtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIsSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbEQsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBQ3hFLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFDdEgsRUFBRSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVqRCxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ2QsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLEVBQUU7Z0JBQ3RDLEVBQUUsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUNsRDtZQUNELFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN6QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDVixDQUFDO0lBQ0QsaUNBQWlDO0lBR2pDLDBCQUFXLEdBQVgsVUFBWSxNQUFNO1FBQ2QsSUFBSSxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQzNFLENBQUM7SUFHRCw2QkFBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQy9CLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxZQUFZO1lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUE7WUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUvQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM5QyxLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhELEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDZCxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRVIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUN4QjthQUNJLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0I7WUFFdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUV2QixLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDeEI7UUFDRCxpQ0FBaUM7UUFDakMsOENBQThDO1FBQzlDLDZDQUE2QzthQUN4QyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtZQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxZQUFZLENBQUM7Z0JBQ2QsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ2pCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztTQUNUO1FBQ0QsaUNBQWlDO0lBQ3JDLENBQUM7SUFJRCwyQkFBWSxHQUFaLFVBQWEsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQzdCLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQUUsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQS9PRDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzZDQUNDO0lBR25CO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7OENBQ1c7SUFHL0I7UUFEQyxRQUFRLENBQUMseUJBQVcsQ0FBQzt5Q0FDTTtJQUs1QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDOzZDQUNVO0lBL0JyQixJQUFJO1FBRGhCLE9BQU87T0FDSyxJQUFJLENBb1FoQjtJQUFELFdBQUM7Q0FwUUQsQUFvUUMsQ0FwUXlCLEVBQUUsQ0FBQyxTQUFTLEdBb1FyQztBQXBRWSxvQkFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdhbWVNYW5hZ2VyIH0gZnJvbSBcIi4vR2FtZU1hbmFnZXJcIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgY2xhc3MgYmlyZCBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcblxyXG4gICAgYW5jaG9yMTogY2MuTm9kZTtcclxuICAgIGFuY2hvcjI6IGNjLk5vZGU7XHJcblxyXG4gICAgZHJhZ2dhYmxlOiBib29sZWFuID0gdHJ1ZTtcclxuICAgIGF0dGFjaFJvcGU6IGJvb2xlYW4gPSB0cnVlO1xyXG5cclxuICAgIGluaXRQb3M6IGNjLlZlYzI7XHJcbiAgICBzdGFydFBvczogY2MuVmVjMjtcclxuXHJcbiAgICBtb3RvckpvaW50OiBjYy5Nb3RvckpvaW50O1xyXG4gICAgcm9wZUpvaW50OiBjYy5Sb3BlSm9pbnQ7XHJcbiAgICByYjogY2MuUmlnaWRCb2R5O1xyXG5cclxuICAgIG1heExlbmd0aDogbnVtYmVyO1xyXG5cclxuICAgIHNjb3JlOiBudW1iZXI7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBzY29yZVBvaW50cyA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHNtb2tlUHJlZmFiczogY2MuUHJlZmFiID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoR2FtZU1hbmFnZXIpXHJcbiAgICBHYW1lTWdyOiBHYW1lTWFuYWdlciA9IG51bGw7XHJcblxyXG4gICAgLy8gPT09PT09PT09PSBUT0RPIDMuMSA9PT09PT09PT09XHJcbiAgICAvLyAxLiBEZWZpbmUgYmlyZFByZWZhYnNcclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBiaXJkUHJlZmFiczogY2MuUHJlZmFiID0gbnVsbDtcclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuaW5pdFByb3BlcnRpZXMoKTtcclxuICAgICAgICB0aGlzLmluaXRSZXNldEJ1dHRvbigpO1xyXG4gICAgICAgIHRoaXMuc2NvcmUgPSAwO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICB1cGRhdGUoKSB7XHJcbiAgICAgICAgdmFyIGRpZmYgPSB0aGlzLmluaXRQb3Muc3ViKHRoaXMubm9kZS5wb3NpdGlvbik7XHJcbiAgICAgICAgdmFyIGFuZ2xlID0gTWF0aC5hdGFuMihkaWZmLngsIGRpZmYueSk7XHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS5wb3NpdGlvbi5zdWIodGhpcy5pbml0UG9zKS5tYWcoKSA8PSAxMCkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuZHJhZ2dhYmxlKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm1vdG9ySm9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yb3BlSm9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5yYi5hbmd1bGFyVmVsb2NpdHkgPSAtYW5nbGUgKiAyMDtcclxuICAgICAgICAgICAgICAgIHRoaXMuYXR0YWNoUm9wZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IxLnNldFBvc2l0aW9uKHRoaXMuaW5pdFBvcy5hZGQoY2MudjIoLTIwLCAwKSkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IyLnNldFBvc2l0aW9uKHRoaXMuaW5pdFBvcy5hZGQoY2MudjIoLTIwLCAwKSkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaWYgKHRoaXMuYXR0YWNoUm9wZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gLSBjYy5taXNjLnJhZGlhbnNUb0RlZ3JlZXMoYW5nbGUpICsgOTA7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IxLnNldFBvc2l0aW9uKHRoaXMubm9kZS5wb3NpdGlvbi5hZGQoY2MudjIoLTE4LCAyKS5yb3RhdGUoLWFuZ2xlICsgOTApKSk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmFuY2hvcjIuc2V0UG9zaXRpb24odGhpcy5ub2RlLnBvc2l0aW9uLmFkZChjYy52MigtMTgsIDIpLnJvdGF0ZSgtYW5nbGUgKyA5MCkpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBpbml0UHJvcGVydGllcygpIHtcclxuICAgICAgICB0aGlzLmFuY2hvcjEgPSBjYy5maW5kKFwiQ2FudmFzL1NsaW5nc2hvdC9TbGluZ3Nob3RGcm9udC9hbmNob3IxXCIpO1xyXG4gICAgICAgIHRoaXMuYW5jaG9yMS5zZXRQb3NpdGlvbih0aGlzLm5vZGUucG9zaXRpb24uYWRkKGNjLnYyKC0yMCwgMCkpKTtcclxuICAgICAgICB0aGlzLmFuY2hvcjIgPSBjYy5maW5kKFwiQ2FudmFzL1NsaW5nc2hvdC9TbGluZ3Nob3RCYWNrL2FuY2hvcjJcIik7XHJcbiAgICAgICAgdGhpcy5hbmNob3IyLnNldFBvc2l0aW9uKHRoaXMubm9kZS5wb3NpdGlvbi5hZGQoY2MudjIoLTIwLCAwKSkpO1xyXG5cclxuICAgICAgICB0aGlzLm1vdG9ySm9pbnQgPSB0aGlzLmdldENvbXBvbmVudChjYy5Nb3RvckpvaW50KTtcclxuICAgICAgICB0aGlzLnJvcGVKb2ludCA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLlJvcGVKb2ludCk7XHJcbiAgICAgICAgdGhpcy5yYiA9IHRoaXMuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSk7XHJcblxyXG4gICAgICAgIHRoaXMuaW5pdFBvcyA9IHRoaXMubm9kZS5wb3NpdGlvbjtcclxuICAgICAgICB0aGlzLnN0YXJ0UG9zID0gdGhpcy5ub2RlLnBvc2l0aW9uO1xyXG5cclxuICAgICAgICB0aGlzLm1heExlbmd0aCA9IHRoaXMucm9wZUpvaW50Lm1heExlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICBpbml0UmVzZXRCdXR0b24oKSB7XHJcbiAgICAgICAgbGV0IGNsaWNrRXZlbnRIYW5kbGVyID0gbmV3IGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIoKTtcclxuICAgICAgICBjbGlja0V2ZW50SGFuZGxlci50YXJnZXQgPSB0aGlzLm5vZGU7XHJcbiAgICAgICAgY2xpY2tFdmVudEhhbmRsZXIuY29tcG9uZW50ID0gXCJiaXJkXCI7XHJcbiAgICAgICAgY2xpY2tFdmVudEhhbmRsZXIuaGFuZGxlciA9IFwicmVzZXRcIjtcclxuXHJcbiAgICAgICAgY2MuZmluZChcIkNhbnZhcy9SZXNldFwiKS5nZXRDb21wb25lbnQoY2MuQnV0dG9uKS5jbGlja0V2ZW50cy5wdXNoKGNsaWNrRXZlbnRIYW5kbGVyKTtcclxuICAgIH1cclxuXHJcbiAgICByZXNldCgpIHtcclxuICAgICAgICB0aGlzLm5vZGUuc2V0UG9zaXRpb24odGhpcy5pbml0UG9zKTtcclxuXHJcbiAgICAgICAgdGhpcy5yYi5saW5lYXJWZWxvY2l0eSA9IGNjLlZlYzIuWkVSTztcclxuICAgICAgICB0aGlzLnJiLmFuZ3VsYXJWZWxvY2l0eSA9IDA7XHJcbiAgICAgICAgdGhpcy5yYi5ncmF2aXR5U2NhbGUgPSAwO1xyXG5cclxuICAgICAgICB0aGlzLm5vZGUuYW5nbGUgPSAwO1xyXG4gICAgICAgIHRoaXMuZHJhZ2dhYmxlID0gdHJ1ZTtcclxuICAgICAgICB0aGlzLmF0dGFjaFJvcGUgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIG9uRW5hYmxlKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5fb25Ub3VjaEJlZ2FuLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5fb25Ub3VjaE1vdmUsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMuX29uVG91Y2hFbmRlZCwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0NBTkNFTCwgdGhpcy5fb25Ub3VjaENhbmNlbCwgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgb25EaXNhYmxlKCkge1xyXG4gICAgICAgIHRoaXMubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMuX29uVG91Y2hCZWdhbiwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCB0aGlzLl9vblRvdWNoTW92ZSwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsIHRoaXMuX29uVG91Y2hFbmRlZCwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9mZihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9DQU5DRUwsIHRoaXMuX29uVG91Y2hDYW5jZWwsIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIF9vblRvdWNoQmVnYW4oZXZlbnQpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZW5hYmxlZEluSGllcmFyY2h5KSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmRyYWdnYWJsZSkge1xyXG4gICAgICAgICAgICB0aGlzLnN0YXJ0UG9zID0gdGhpcy5ub2RlLnBvc2l0aW9uO1xyXG4gICAgICAgICAgICB0aGlzLm1vdG9ySm9pbnQuZW5hYmxlZCA9IGZhbHNlO1xyXG4gICAgICAgICAgICB0aGlzLnJiLmdyYXZpdHlTY2FsZSA9IDA7XHJcbiAgICAgICAgICAgIHRoaXMucmIubGluZWFyVmVsb2NpdHkgPSBjYy5WZWMyLlpFUk87XHJcbiAgICAgICAgICAgIHRoaXMucmIuYW5ndWxhclZlbG9jaXR5ID0gMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgX29uVG91Y2hNb3ZlKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWRJbkhpZXJhcmNoeSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5kcmFnZ2FibGUpIHtcclxuICAgICAgICAgICAgbGV0IHN0YXJ0ID0gZXZlbnQuZ2V0U3RhcnRMb2NhdGlvbigpO1xyXG4gICAgICAgICAgICBsZXQgY3VyID0gZXZlbnQuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICAgICAgY3VyLnN1YlNlbGYoc3RhcnQpO1xyXG5cclxuICAgICAgICAgICAgbGV0IGN1cl92ID0gY2MudjIoY3VyLngsIGN1ci55KTtcclxuICAgICAgICAgICAgaWYgKGN1cl92Lm1hZygpID4gdGhpcy5tYXhMZW5ndGgpIHtcclxuICAgICAgICAgICAgICAgIGN1cl92Lm5vcm1hbGl6ZVNlbGYoKS5tdWxTZWxmKHRoaXMubWF4TGVuZ3RoKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKHRoaXMuc3RhcnRQb3MuYWRkKGN1cl92KSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnJiLmxpbmVhclZlbG9jaXR5ID0gY2MuVmVjMi5aRVJPO1xyXG4gICAgICAgICAgICB0aGlzLnJiLmFuZ3VsYXJWZWxvY2l0eSA9IDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBfb25Ub3VjaEVuZGVkKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWRJbkhpZXJhcmNoeSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmRyYWdFbmQoKTtcclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgX29uVG91Y2hDYW5jZWwoZXZlbnQpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZW5hYmxlZEluSGllcmFyY2h5KSByZXR1cm47XHJcblxyXG4gICAgICAgIHRoaXMuZHJhZ0VuZCgpO1xyXG5cclxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgIH1cclxuXHJcbiAgICBkcmFnRW5kKCkge1xyXG4gICAgICAgIGlmICghdGhpcy5kcmFnZ2FibGUpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMubm9kZS5wb3NpdGlvbi5zdWIodGhpcy5zdGFydFBvcykubWFnKCkgPiAxMCkge1xyXG4gICAgICAgICAgICB0aGlzLmRyYWdnYWJsZSA9IGZhbHNlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5tb3RvckpvaW50LmVuYWJsZWQgPSB0cnVlO1xyXG5cclxuICAgICAgICB0aGlzLnJiLmdyYXZpdHlTY2FsZSA9IDE7XHJcbiAgICAgICAgdGhpcy5yYi5saW5lYXJWZWxvY2l0eSA9IGNjLnYyKDEsIDApO1xyXG5cclxuICAgICAgICAvLyA9PT09PT09PT09IFRPRE8gMy4zID09PT09PT09PT1cclxuICAgICAgICAvLyAxLiBTcGxpdCB0byB0d28gYmlyZHMgYWZ0ZXIgMC41IHNlYy5cclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc3BsaXQoKTtcclxuICAgICAgICB9LCAwLjUpO1xyXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgICAgICB0aGlzLkdhbWVNZ3IucGxheUVmZmVjdCgpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMy4yID09PT09PT09PT1cclxuICAgIC8vIDEuIEluc3RhbnRpYXRlIGFub3RoZXIgYmlyZC5cclxuICAgIC8vIDIuIFNldCB0aGUgbmV3IGJpcmQncyBwb3NpdGlvbiB0byB0aGlzIGJpcmQncyB4IGFuZCB5ICsgMTAuXHJcbiAgICAvLyAzLiBTZXQgdGhlIG5ldyBiaXJkJ3MgbGluZWFyVmVsb2NpdHkgZXF1YWxzIHRvIHRoaXMgYmlyZCdzIHZlbG9jaXR5IHggYW5kIHRoaXMgYmlyZCdzIHZlbG9jaXR5ICh5ICsgNTApLlxyXG4gICAgLy8gNC4gVXNlIGFkZENoaWxkKCkgZnVuY3Rpb24gdG8gcGxhY2UgcHJlZmFiIGludG8gc2NlbmUuXHJcbiAgICAvLyA1LiBEZXN0cm95IHRoZSBzcGxpdCBiaXJkIGFmdGVyIDUgc2Vjb25kcywgaWYgdGhlcmUgZXhpc3QgdGhlIHNtb2tlIGdlbmVyYXRlZCBieSB0aGUgYmlyZCwgYWxzbyBkZXN0cm95IGl0LlxyXG4gICAgc3BsaXQoKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzcGxpdFwiKTtcclxuICAgICAgICB2YXIgYmlyZF9zcGxpdCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYmlyZFByZWZhYnMpO1xyXG4gICAgICAgIGJpcmRfc3BsaXQuc2V0UG9zaXRpb24odGhpcy5ub2RlLnBvc2l0aW9uLngsIHRoaXMubm9kZS5wb3NpdGlvbi55ICsgMTApO1xyXG4gICAgICAgIGJpcmRfc3BsaXQuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkubGluZWFyVmVsb2NpdHkgPSBjYy52Mih0aGlzLnJiLmxpbmVhclZlbG9jaXR5LngsIHRoaXMucmIubGluZWFyVmVsb2NpdHkueSArIDUwKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL1NsaW5nc2hvdFwiKS5hZGRDaGlsZChiaXJkX3NwbGl0KTtcclxuXHJcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAoY2MuZmluZChcIkNhbnZhcy9FbnZpcm9ubWVudC9zbW9rZTJcIikpIHtcclxuICAgICAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnQvc21va2UyXCIpLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBiaXJkX3NwbGl0LmRlc3Ryb3koKTtcclxuICAgICAgICB9LCA1KTtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbiAgICB1cGRhdGVTY29yZShudW1iZXIpIHtcclxuICAgICAgICB0aGlzLnNjb3JlICs9IG51bWJlcjtcclxuICAgICAgICB0aGlzLnNjb3JlUG9pbnRzLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gdGhpcy5zY29yZS50b1N0cmluZygpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikge1xyXG4gICAgICAgIGlmIChvdGhlci50YWcgPT0gMSkgeyAvLyBlbmVteSB0YWdcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJCZWdpbkNvbnRhY3RcIilcclxuICAgICAgICAgICAgY29uc29sZS5sb2coY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCkucG9pbnRzKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBzbW9rZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuc21va2VQcmVmYWJzKTtcclxuICAgICAgICAgICAgc21va2Uuc2V0UG9zaXRpb24oY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCkucG9pbnRzWzBdKTtcclxuXHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnRcIikuYWRkQ2hpbGQoc21va2UpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBzbW9rZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIH0sIDEuNSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVNjb3JlKDMwKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAob3RoZXIudGFnID09IDIpIHsgLy8gZ2FtZSBpdGVtIHRhZ1xyXG5cclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJUcmlnZ2VyXCIpO1xyXG5cclxuICAgICAgICAgICAgb3RoZXIubm9kZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIHRoaXMudXBkYXRlU2NvcmUoMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyA9PT09PT09PT09IFRPRE8gMi4xID09PT09PT09PT1cclxuICAgICAgICAvLyAxLiBJZiBjb250YWN0IHdpdGggYSBzcGlrZSwgcmVzZXQgdGhlIGJpcmQgXHJcbiAgICAgICAgLy8gICAgdG8gdGhlIGluaXRpYWwgcG9zaXRpb24gYWZ0ZXIgMSBzZWNvbmQuXHJcbiAgICAgICAgZWxzZSBpZiAob3RoZXIubm9kZS5uYW1lID09IFwiU3Bpa2VcIikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImh1cnRcIik7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMucmVzZXQoKTtcclxuICAgICAgICAgICAgfSwgMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgb25FbmRDb250YWN0KGNvbnRhY3QsIHNlbGYsIG90aGVyKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLnRhZyA9PSAxKSBvdGhlci50YWcgPSAwO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==