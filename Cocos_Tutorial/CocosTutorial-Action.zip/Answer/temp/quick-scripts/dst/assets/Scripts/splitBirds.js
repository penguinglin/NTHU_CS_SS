
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/splitBirds.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bf68aCPzqtOyIpeTJZUELth', 'splitBirds');
// Scripts/splitBirds.ts

Object.defineProperty(exports, "__esModule", { value: true });
var bird_1 = require("./bird");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var split_bird = /** @class */ (function (_super) {
    __extends(split_bird, _super);
    function split_bird() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.draggable = true;
        _this.attachRope = true;
        _this.smokePrefabs = null;
        // ========== TODO 3.4 ==========
        // 1. Define bird's component.
        _this._bird = null;
        return _this;
    }
    // ==============================
    split_bird.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    // ========== TODO 3.5 ==========
    // 1. Get the bird's component from bird node when instantiated.
    split_bird.prototype.start = function () {
        this._bird = cc.find("Canvas/Slingshot/bird").getComponent(bird_1.bird);
    };
    // ==============================
    split_bird.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact");
            console.log(contact.getWorldManifold().points);
            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);
            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);
            this._bird.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag
            console.log("Trigger");
            other.node.destroy();
            this._bird.updateScore(10);
        }
    };
    split_bird.prototype.onEndContact = function (contact, self, other) {
        if (other.tag == 1)
            other.tag = 0;
    };
    __decorate([
        property(cc.Prefab)
    ], split_bird.prototype, "smokePrefabs", void 0);
    __decorate([
        property(bird_1.bird)
    ], split_bird.prototype, "_bird", void 0);
    split_bird = __decorate([
        ccclass
    ], split_bird);
    return split_bird;
}(cc.Component));
exports.default = split_bird;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcc3BsaXRCaXJkcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsK0JBQThCO0FBRXhCLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXdDLDhCQUFZO0lBQXBEO1FBQUEscUVBeUVDO1FBcEVHLGVBQVMsR0FBWSxJQUFJLENBQUM7UUFDMUIsZ0JBQVUsR0FBWSxJQUFJLENBQUM7UUFhM0Isa0JBQVksR0FBYyxJQUFJLENBQUM7UUFFL0IsaUNBQWlDO1FBQ2pDLDhCQUE4QjtRQUU5QixXQUFLLEdBQVMsSUFBSSxDQUFDOztJQWlEdkIsQ0FBQztJQWhERyxpQ0FBaUM7SUFHakMsMkJBQU0sR0FBTjtRQUNJLEVBQUUsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO0lBQ25ELENBQUM7SUFFRCxpQ0FBaUM7SUFDakMsZ0VBQWdFO0lBQ2hFLDBCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBSSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUNELGlDQUFpQztJQUdqQyxtQ0FBYyxHQUFkLFVBQWUsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQy9CLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsRUFBRSxZQUFZO1lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUE7WUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUUvQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUM5QyxLQUFLLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRXhELEVBQUUsQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnQkFDZCxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEIsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRVIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7U0FDOUI7YUFDSSxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCO1lBRXZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFdkIsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM5QjtJQUNMLENBQUM7SUFJRCxpQ0FBWSxHQUFaLFVBQWEsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQzdCLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQUUsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQWpERDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO29EQUNXO0lBSy9CO1FBREMsUUFBUSxDQUFDLFdBQUksQ0FBQzs2Q0FDSTtJQXhCRixVQUFVO1FBRDlCLE9BQU87T0FDYSxVQUFVLENBeUU5QjtJQUFELGlCQUFDO0NBekVELEFBeUVDLENBekV1QyxFQUFFLENBQUMsU0FBUyxHQXlFbkQ7a0JBekVvQixVQUFVIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYmlyZCB9IGZyb20gXCIuL2JpcmRcIjtcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBzcGxpdF9iaXJkIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBhbmNob3IxOiBjYy5Ob2RlO1xyXG4gICAgYW5jaG9yMjogY2MuTm9kZTtcclxuXHJcbiAgICBkcmFnZ2FibGU6IGJvb2xlYW4gPSB0cnVlO1xyXG4gICAgYXR0YWNoUm9wZTogYm9vbGVhbiA9IHRydWU7XHJcblxyXG4gICAgaW5pdFBvczogY2MuVmVjMjtcclxuICAgIHN0YXJ0UG9zOiBjYy5WZWMyO1xyXG5cclxuICAgIG1vdG9ySm9pbnQ6IGNjLk1vdG9ySm9pbnQ7XHJcbiAgICByb3BlSm9pbnQ6IGNjLlJvcGVKb2ludDtcclxuICAgIHJiOiBjYy5SaWdpZEJvZHk7XHJcblxyXG4gICAgbWF4TGVuZ3RoOiBudW1iZXI7XHJcblxyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBzbW9rZVByZWZhYnM6IGNjLlByZWZhYiA9IG51bGw7XHJcblxyXG4gICAgLy8gPT09PT09PT09PSBUT0RPIDMuNCA9PT09PT09PT09XHJcbiAgICAvLyAxLiBEZWZpbmUgYmlyZCdzIGNvbXBvbmVudC5cclxuICAgIEBwcm9wZXJ0eShiaXJkKVxyXG4gICAgX2JpcmQ6IGJpcmQgPSBudWxsO1xyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT0gVE9ETyAzLjUgPT09PT09PT09PVxyXG4gICAgLy8gMS4gR2V0IHRoZSBiaXJkJ3MgY29tcG9uZW50IGZyb20gYmlyZCBub2RlIHdoZW4gaW5zdGFudGlhdGVkLlxyXG4gICAgc3RhcnQoKSB7XHJcbiAgICAgICAgdGhpcy5fYmlyZCA9IGNjLmZpbmQoXCJDYW52YXMvU2xpbmdzaG90L2JpcmRcIikuZ2V0Q29tcG9uZW50KGJpcmQpO1xyXG4gICAgfVxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG5cclxuICAgIG9uQmVnaW5Db250YWN0KGNvbnRhY3QsIHNlbGYsIG90aGVyKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLnRhZyA9PSAxKSB7IC8vIGVuZW15IHRhZ1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkJlZ2luQ29udGFjdFwiKVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhjb250YWN0LmdldFdvcmxkTWFuaWZvbGQoKS5wb2ludHMpO1xyXG5cclxuICAgICAgICAgICAgdmFyIHNtb2tlID0gY2MuaW5zdGFudGlhdGUodGhpcy5zbW9rZVByZWZhYnMpO1xyXG4gICAgICAgICAgICBzbW9rZS5zZXRQb3NpdGlvbihjb250YWN0LmdldFdvcmxkTWFuaWZvbGQoKS5wb2ludHNbMF0pO1xyXG5cclxuICAgICAgICAgICAgY2MuZmluZChcIkNhbnZhcy9FbnZpcm9ubWVudFwiKS5hZGRDaGlsZChzbW9rZSk7XHJcbiAgICAgICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgICAgIHNtb2tlLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgfSwgMS41KTtcclxuXHJcbiAgICAgICAgICAgIHRoaXMuX2JpcmQudXBkYXRlU2NvcmUoMzApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIGlmIChvdGhlci50YWcgPT0gMikgeyAvLyBnYW1lIGl0ZW0gdGFnXHJcblxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlRyaWdnZXJcIik7XHJcblxyXG4gICAgICAgICAgICBvdGhlci5ub2RlLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgdGhpcy5fYmlyZC51cGRhdGVTY29yZSgxMCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG4gICAgb25FbmRDb250YWN0KGNvbnRhY3QsIHNlbGYsIG90aGVyKSB7XHJcbiAgICAgICAgaWYgKG90aGVyLnRhZyA9PSAxKSBvdGhlci50YWcgPSAwO1xyXG4gICAgfVxyXG5cclxuXHJcblxyXG5cclxufVxyXG4iXX0=