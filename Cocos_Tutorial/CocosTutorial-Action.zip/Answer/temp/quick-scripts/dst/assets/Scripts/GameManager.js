
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/GameManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db5ccu2mJpFE6gK1j6VIz8U', 'GameManager');
// Scripts/GameManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.GameManager = void 0;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GameManager = /** @class */ (function (_super) {
    __extends(GameManager, _super);
    function GameManager() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bgm = null;
        _this.flyingSE = null;
        _this.pigsmPrefabs = null;
        _this.pigbgPrefabs = null;
        return _this;
    }
    GameManager.prototype.start = function () {
        this.playBGM();
        this.pigInstantiate();
    };
    GameManager.prototype.playBGM = function () {
        cc.audioEngine.playMusic(this.bgm, true);
    };
    GameManager.prototype.playEffect = function () {
        cc.audioEngine.playEffect(this.flyingSE, false);
    };
    GameManager.prototype.pigInstantiate = function () {
        var pig_sm = cc.instantiate(this.pigsmPrefabs);
        pig_sm.setPosition(822.711, 240.513);
        cc.find("Canvas/Environment").addChild(pig_sm);
        var pig_bg = cc.instantiate(this.pigbgPrefabs);
        pig_bg.setPosition(822.711, 335.628);
        cc.find("Canvas/Environment").addChild(pig_bg);
    };
    __decorate([
        property(cc.AudioClip)
    ], GameManager.prototype, "bgm", void 0);
    __decorate([
        property(cc.AudioClip)
    ], GameManager.prototype, "flyingSE", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "pigsmPrefabs", void 0);
    __decorate([
        property(cc.Prefab)
    ], GameManager.prototype, "pigbgPrefabs", void 0);
    GameManager = __decorate([
        ccclass
    ], GameManager);
    return GameManager;
}(cc.Component));
exports.GameManager = GameManager;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcR2FtZU1hbmFnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBTSxJQUFBLEtBQXdCLEVBQUUsQ0FBQyxVQUFVLEVBQW5DLE9BQU8sYUFBQSxFQUFFLFFBQVEsY0FBa0IsQ0FBQztBQUc1QztJQUFpQywrQkFBWTtJQUE3QztRQUFBLHFFQXdDQztRQXJDRyxTQUFHLEdBQWlCLElBQUksQ0FBQztRQUd6QixjQUFRLEdBQWlCLElBQUksQ0FBQztRQUk5QixrQkFBWSxHQUFjLElBQUksQ0FBQztRQUcvQixrQkFBWSxHQUFjLElBQUksQ0FBQzs7SUEyQm5DLENBQUM7SUF4QkcsMkJBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsNkJBQU8sR0FBUDtRQUNJLEVBQUUsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELGdDQUFVLEdBQVY7UUFDSSxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELENBQUM7SUFFRCxvQ0FBYyxHQUFkO1FBRUksSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDL0MsTUFBTSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckMsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUvQyxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMvQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUNyQyxFQUFFLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFuQ0Q7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQzs0Q0FDRTtJQUd6QjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDO2lEQUNPO0lBSTlCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7cURBQ1c7SUFHL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztxREFDVztJQWJ0QixXQUFXO1FBRHZCLE9BQU87T0FDSyxXQUFXLENBd0N2QjtJQUFELGtCQUFDO0NBeENELEFBd0NDLENBeENnQyxFQUFFLENBQUMsU0FBUyxHQXdDNUM7QUF4Q1ksa0NBQVciLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGNsYXNzIEdhbWVNYW5hZ2VyIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuQXVkaW9DbGlwKVxyXG4gICAgYmdtOiBjYy5BdWRpb0NsaXAgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5BdWRpb0NsaXApXHJcbiAgICBmbHlpbmdTRTogY2MuQXVkaW9DbGlwID0gbnVsbDtcclxuXHJcblxyXG4gICAgQHByb3BlcnR5KGNjLlByZWZhYilcclxuICAgIHBpZ3NtUHJlZmFiczogY2MuUHJlZmFiID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuUHJlZmFiKVxyXG4gICAgcGlnYmdQcmVmYWJzOiBjYy5QcmVmYWIgPSBudWxsO1xyXG5cclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnBsYXlCR00oKTtcclxuICAgICAgICB0aGlzLnBpZ0luc3RhbnRpYXRlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcGxheUJHTSgpe1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlNdXNpYyh0aGlzLmJnbSwgdHJ1ZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcGxheUVmZmVjdCgpe1xyXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5mbHlpbmdTRSwgZmFsc2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHBpZ0luc3RhbnRpYXRlKCkge1xyXG5cclxuICAgICAgICB2YXIgcGlnX3NtID0gY2MuaW5zdGFudGlhdGUodGhpcy5waWdzbVByZWZhYnMpO1xyXG4gICAgICAgIHBpZ19zbS5zZXRQb3NpdGlvbig4MjIuNzExLCAyNDAuNTEzKTtcclxuICAgICAgICBjYy5maW5kKFwiQ2FudmFzL0Vudmlyb25tZW50XCIpLmFkZENoaWxkKHBpZ19zbSk7XHJcblxyXG4gICAgICAgIHZhciBwaWdfYmcgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnBpZ2JnUHJlZmFicyk7XHJcbiAgICAgICAgcGlnX2JnLnNldFBvc2l0aW9uKDgyMi43MTEsIDMzNS42MjgpO1xyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnRcIikuYWRkQ2hpbGQocGlnX2JnKTtcclxuICAgIH1cclxuXHJcbn1cclxuIl19