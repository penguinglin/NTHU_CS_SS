
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/platform.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a1c2a1ZYJNBFqNVdhAnBXFr', 'platform');
// Scripts/platform.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Platform = /** @class */ (function (_super) {
    __extends(Platform, _super);
    function Platform() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Vertical_platform = null;
        _this.Horizontal_platform = null;
        _this.Vertical_spike = null;
        _this.Horizontal_spike = null;
        return _this;
    }
    // ========== TODO 1.2 ==========
    // 1. Let platforms continue to move during the game.
    Platform.prototype.start = function () {
        this.platformMove("vertical", 1, this.Vertical_platform);
        this.platformMove("horizontal", 1, this.Horizontal_platform);
        // ========= TODO 1.3.1 =========
        // 1. Let the vertical spike move 
        this.spikeMove(1, this.Vertical_spike);
        // ==============================
    };
    // ==============================
    // ========= TODO 1.3.2 =========
    // 1. Let the horizontal spike always stay at the initial local position,
    //    So, it will move with its parent correctly
    Platform.prototype.update = function () {
        this.Horizontal_spike.setPosition(0, 30);
    };
    // ==============================
    // ========== TODO 1.1 ==========
    // 1. Define the action sequence.
    //    (Hint: you can use cc.sequence and cc.easeInOut to help you design actions.)
    // 2. Use moveDir to decide whether you should move vertical or horizontal.
    // 3. Let a variable action represent the "repeated action".
    //    (Hint: cc.repeatForever)
    // 4. Use schedule function to set the delay time when game start.
    Platform.prototype.platformMove = function (moveDir, delayTime, platform) {
        var action;
        var easeRate = 2;
        var sequence1 = cc.sequence(cc.moveBy(2, 0, 120).easing(cc.easeInOut(easeRate)), cc.moveBy(2, 0, -120).easing(cc.easeInOut(easeRate)));
        var sequence2 = cc.sequence(cc.moveBy(2, 120, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(2, -120, 0).easing(cc.easeInOut(easeRate)));
        if (moveDir == "vertical") {
            action = cc.repeatForever(sequence1);
        }
        else {
            action = cc.repeatForever(sequence2);
        }
        this.scheduleOnce(function () {
            platform.runAction(action);
        }, delayTime);
    };
    // ==============================
    Platform.prototype.spikeMove = function (delayTime, spike) {
        var action;
        var easeRate = 2;
        var sequence = cc.sequence(cc.moveBy(1, 40, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(1, -40, 0).easing(cc.easeInOut(easeRate)));
        action = cc.repeatForever(sequence);
        this.scheduleOnce(function () {
            spike.runAction(action);
        }, delayTime);
    };
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Vertical_platform", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Horizontal_platform", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Vertical_spike", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Horizontal_spike", void 0);
    Platform = __decorate([
        ccclass
    ], Platform);
    return Platform;
}(cc.Component));
exports.default = Platform;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xccGxhdGZvcm0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFNLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQXNDLDRCQUFZO0lBQWxEO1FBQUEscUVBc0VDO1FBbkVHLHVCQUFpQixHQUFZLElBQUksQ0FBQztRQUdsQyx5QkFBbUIsR0FBWSxJQUFJLENBQUM7UUFHcEMsb0JBQWMsR0FBWSxJQUFJLENBQUM7UUFHL0Isc0JBQWdCLEdBQVksSUFBSSxDQUFDOztJQTBEckMsQ0FBQztJQXhERyxpQ0FBaUM7SUFDakMscURBQXFEO0lBQ3JELHdCQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQzdELGlDQUFpQztRQUNqQyxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3ZDLGlDQUFpQztJQUNyQyxDQUFDO0lBQ0QsaUNBQWlDO0lBRWpDLGlDQUFpQztJQUNqQyx5RUFBeUU7SUFDekUsZ0RBQWdEO0lBQ2hELHlCQUFNLEdBQU47UUFDSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsaUNBQWlDO0lBR2pDLGlDQUFpQztJQUNqQyxpQ0FBaUM7SUFDakMsa0ZBQWtGO0lBQ2xGLDJFQUEyRTtJQUMzRSw0REFBNEQ7SUFDNUQsOEJBQThCO0lBQzlCLGtFQUFrRTtJQUNsRSwrQkFBWSxHQUFaLFVBQWEsT0FBZSxFQUFFLFNBQWlCLEVBQUUsUUFBaUI7UUFDOUQsSUFBSSxNQUFpQixDQUFDO1FBQ3RCLElBQUksUUFBUSxHQUFXLENBQUMsQ0FBQztRQUN6QixJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SSxJQUFJLFNBQVMsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2SSxJQUFJLE9BQU8sSUFBSSxVQUFVLEVBQUU7WUFDdkIsTUFBTSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDeEM7YUFDSTtZQUNELE1BQU0sR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQ3hDO1FBQ0QsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDL0IsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ2xCLENBQUM7SUFDRCxpQ0FBaUM7SUFHakMsNEJBQVMsR0FBVCxVQUFVLFNBQWlCLEVBQUUsS0FBYztRQUN2QyxJQUFJLE1BQWlCLENBQUM7UUFDdEIsSUFBSSxRQUFRLEdBQVcsQ0FBQyxDQUFDO1FBQ3pCLElBQUksUUFBUSxHQUFHLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BJLE1BQU0sR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDZCxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVCLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUNsQixDQUFDO0lBakVEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7dURBQ2dCO0lBR2xDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7eURBQ2tCO0lBR3BDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7b0RBQ2E7SUFHL0I7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztzREFDZTtJQVpoQixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBc0U1QjtJQUFELGVBQUM7Q0F0RUQsQUFzRUMsQ0F0RXFDLEVBQUUsQ0FBQyxTQUFTLEdBc0VqRDtrQkF0RW9CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBjYy5fZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3NcclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGxhdGZvcm0gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgVmVydGljYWxfcGxhdGZvcm06IGNjLk5vZGUgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5Ob2RlKVxyXG4gICAgSG9yaXpvbnRhbF9wbGF0Zm9ybTogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBWZXJ0aWNhbF9zcGlrZTogY2MuTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXHJcbiAgICBIb3Jpem9udGFsX3NwaWtlOiBjYy5Ob2RlID0gbnVsbDtcclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMS4yID09PT09PT09PT1cclxuICAgIC8vIDEuIExldCBwbGF0Zm9ybXMgY29udGludWUgdG8gbW92ZSBkdXJpbmcgdGhlIGdhbWUuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLnBsYXRmb3JtTW92ZShcInZlcnRpY2FsXCIsIDEsIHRoaXMuVmVydGljYWxfcGxhdGZvcm0pO1xyXG4gICAgICAgIHRoaXMucGxhdGZvcm1Nb3ZlKFwiaG9yaXpvbnRhbFwiLCAxLCB0aGlzLkhvcml6b250YWxfcGxhdGZvcm0pO1xyXG4gICAgICAgIC8vID09PT09PT09PSBUT0RPIDEuMy4xID09PT09PT09PVxyXG4gICAgICAgIC8vIDEuIExldCB0aGUgdmVydGljYWwgc3Bpa2UgbW92ZSBcclxuICAgICAgICB0aGlzLnNwaWtlTW92ZSgxLCB0aGlzLlZlcnRpY2FsX3NwaWtlKTtcclxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIC8vID09PT09PT09PSBUT0RPIDEuMy4yID09PT09PT09PVxyXG4gICAgLy8gMS4gTGV0IHRoZSBob3Jpem9udGFsIHNwaWtlIGFsd2F5cyBzdGF5IGF0IHRoZSBpbml0aWFsIGxvY2FsIHBvc2l0aW9uLFxyXG4gICAgLy8gICAgU28sIGl0IHdpbGwgbW92ZSB3aXRoIGl0cyBwYXJlbnQgY29ycmVjdGx5XHJcbiAgICB1cGRhdGUoKSB7XHJcbiAgICAgICAgdGhpcy5Ib3Jpem9udGFsX3NwaWtlLnNldFBvc2l0aW9uKDAsIDMwKTtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMS4xID09PT09PT09PT1cclxuICAgIC8vIDEuIERlZmluZSB0aGUgYWN0aW9uIHNlcXVlbmNlLlxyXG4gICAgLy8gICAgKEhpbnQ6IHlvdSBjYW4gdXNlIGNjLnNlcXVlbmNlIGFuZCBjYy5lYXNlSW5PdXQgdG8gaGVscCB5b3UgZGVzaWduIGFjdGlvbnMuKVxyXG4gICAgLy8gMi4gVXNlIG1vdmVEaXIgdG8gZGVjaWRlIHdoZXRoZXIgeW91IHNob3VsZCBtb3ZlIHZlcnRpY2FsIG9yIGhvcml6b250YWwuXHJcbiAgICAvLyAzLiBMZXQgYSB2YXJpYWJsZSBhY3Rpb24gcmVwcmVzZW50IHRoZSBcInJlcGVhdGVkIGFjdGlvblwiLlxyXG4gICAgLy8gICAgKEhpbnQ6IGNjLnJlcGVhdEZvcmV2ZXIpXHJcbiAgICAvLyA0LiBVc2Ugc2NoZWR1bGUgZnVuY3Rpb24gdG8gc2V0IHRoZSBkZWxheSB0aW1lIHdoZW4gZ2FtZSBzdGFydC5cclxuICAgIHBsYXRmb3JtTW92ZShtb3ZlRGlyOiBzdHJpbmcsIGRlbGF5VGltZTogbnVtYmVyLCBwbGF0Zm9ybTogY2MuTm9kZSkge1xyXG4gICAgICAgIGxldCBhY3Rpb246IGNjLkFjdGlvbjtcclxuICAgICAgICBsZXQgZWFzZVJhdGU6IG51bWJlciA9IDI7XHJcbiAgICAgICAgdmFyIHNlcXVlbmNlMSA9IGNjLnNlcXVlbmNlKGNjLm1vdmVCeSgyLCAwLCAxMjApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSwgY2MubW92ZUJ5KDIsIDAsIC0xMjApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSk7XHJcbiAgICAgICAgdmFyIHNlcXVlbmNlMiA9IGNjLnNlcXVlbmNlKGNjLm1vdmVCeSgyLCAxMjAsIDApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSwgY2MubW92ZUJ5KDIsIC0xMjAsIDApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSk7XHJcbiAgICAgICAgaWYgKG1vdmVEaXIgPT0gXCJ2ZXJ0aWNhbFwiKSB7XHJcbiAgICAgICAgICAgIGFjdGlvbiA9IGNjLnJlcGVhdEZvcmV2ZXIoc2VxdWVuY2UxKTtcclxuICAgICAgICB9IFxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBhY3Rpb24gPSBjYy5yZXBlYXRGb3JldmVyKHNlcXVlbmNlMik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgcGxhdGZvcm0ucnVuQWN0aW9uKGFjdGlvbik7XHJcbiAgICAgICAgfSwgZGVsYXlUaW1lKTtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbiAgICBzcGlrZU1vdmUoZGVsYXlUaW1lOiBudW1iZXIsIHNwaWtlOiBjYy5Ob2RlKSB7XHJcbiAgICAgICAgbGV0IGFjdGlvbjogY2MuQWN0aW9uO1xyXG4gICAgICAgIGxldCBlYXNlUmF0ZTogbnVtYmVyID0gMjtcclxuICAgICAgICB2YXIgc2VxdWVuY2UgPSBjYy5zZXF1ZW5jZShjYy5tb3ZlQnkoMSwgNDAsIDApLmVhc2luZyhjYy5lYXNlSW5PdXQoZWFzZVJhdGUpKSwgY2MubW92ZUJ5KDEsIC00MCwgMCkuZWFzaW5nKGNjLmVhc2VJbk91dChlYXNlUmF0ZSkpKTtcclxuICAgICAgICBhY3Rpb24gPSBjYy5yZXBlYXRGb3JldmVyKHNlcXVlbmNlKTtcclxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIHNwaWtlLnJ1bkFjdGlvbihhY3Rpb24pO1xyXG4gICAgICAgIH0sIGRlbGF5VGltZSk7XHJcbiAgICB9XHJcblxyXG59Il19