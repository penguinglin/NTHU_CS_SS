import { bird } from "./bird";

const { ccclass, property } = cc._decorator;

@ccclass
export default class split_bird extends cc.Component {

    anchor1: cc.Node;
    anchor2: cc.Node;

    draggable: boolean = true;
    attachRope: boolean = true;

    initPos: cc.Vec2;
    startPos: cc.Vec2;

    motorJoint: cc.MotorJoint;
    ropeJoint: cc.RopeJoint;
    rb: cc.RigidBody;

    maxLength: number;


    @property(cc.Prefab)
    smokePrefabs: cc.Prefab = null;

    // ========== TODO 3.4 ==========
    // 1. Define bird's component.
    @property(bird)
    _bird: bird = null;
    // ==============================


    onLoad() {
        cc.director.getPhysicsManager().enabled = true;
    }

    // ========== TODO 3.5 ==========
    // 1. Get the bird's component from bird node when instantiated.
    start() {
        this._bird = cc.find("Canvas/Slingshot/bird").getComponent(bird);
    }
    // ==============================


    onBeginContact(contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact")
            console.log(contact.getWorldManifold().points);

            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);

            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);

            this._bird.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag

            console.log("Trigger");

            other.node.destroy();
            this._bird.updateScore(10);
        }
    }



    onEndContact(contact, self, other) {
        if (other.tag == 1) other.tag = 0;
    }




}
