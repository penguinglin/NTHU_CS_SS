const { ccclass, property } = cc._decorator;

@ccclass
export default class Platform extends cc.Component {

    @property(cc.Node)
    Vertical_platform: cc.Node = null;

    @property(cc.Node)
    Horizontal_platform: cc.Node = null;

    @property(cc.Node)
    Vertical_spike: cc.Node = null;

    @property(cc.Node)
    Horizontal_spike: cc.Node = null;

    // ========== TODO 1.2 ==========
    // 1. Let platforms continue to move during the game.
    start() {
        this.platformMove("vertical", 1, this.Vertical_platform);
        this.platformMove("horizontal", 1, this.Horizontal_platform);
        // ========= TODO 1.3.1 =========
        // 1. Let the vertical spike move 
        this.spikeMove(1, this.Vertical_spike);
        // ==============================
    }
    // ==============================

    // ========= TODO 1.3.2 =========
    // 1. Let the horizontal spike always stay at the initial local position,
    //    So, it will move with its parent correctly
    update() {
        this.Horizontal_spike.setPosition(0, 30);
    }
    // ==============================


    // ========== TODO 1.1 ==========
    // 1. Define the action sequence.
    //    (Hint: you can use cc.sequence and cc.easeInOut to help you design actions.)
    // 2. Use moveDir to decide whether you should move vertical or horizontal.
    // 3. Let a variable action represent the "repeated action".
    //    (Hint: cc.repeatForever)
    // 4. Use schedule function to set the delay time when game start.
    platformMove(moveDir: string, delayTime: number, platform: cc.Node) {
        let action: cc.Action;
        let easeRate: number = 2;
        var sequence1 = cc.sequence(cc.moveBy(2, 0, 120).easing(cc.easeInOut(easeRate)), cc.moveBy(2, 0, -120).easing(cc.easeInOut(easeRate)));
        var sequence2 = cc.sequence(cc.moveBy(2, 120, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(2, -120, 0).easing(cc.easeInOut(easeRate)));
        if (moveDir == "vertical") {
            action = cc.repeatForever(sequence1);
        } 
        else {
            action = cc.repeatForever(sequence2);
        }
        this.scheduleOnce(function () {
            platform.runAction(action);
        }, delayTime);
    }
    // ==============================


    spikeMove(delayTime: number, spike: cc.Node) {
        let action: cc.Action;
        let easeRate: number = 2;
        var sequence = cc.sequence(cc.moveBy(1, 40, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(1, -40, 0).easing(cc.easeInOut(easeRate)));
        action = cc.repeatForever(sequence);
        this.scheduleOnce(function () {
            spike.runAction(action);
        }, delayTime);
    }

}