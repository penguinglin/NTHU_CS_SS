"use strict";
cc._RF.push(module, 'a1c2a1ZYJNBFqNVdhAnBXFr', 'platform');
// Scripts/platform.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Platform = /** @class */ (function (_super) {
    __extends(Platform, _super);
    function Platform() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Vertical_platform = null;
        _this.Horizontal_platform = null;
        _this.Vertical_spike = null;
        _this.Horizontal_spike = null;
        return _this;
    }
    // ========== TODO 1.2 ==========
    // 1. Let platforms continue to move during the game.
    Platform.prototype.start = function () {
        this.platformMove("vertical", 1, this.Vertical_platform);
        this.platformMove("horizontal", 1, this.Horizontal_platform);
        // ========= TODO 1.3.1 =========
        // 1. Let the vertical spike move 
        this.spikeMove(1, this.Vertical_spike);
        // ==============================
    };
    // ==============================
    // ========= TODO 1.3.2 =========
    // 1. Let the horizontal spike always stay at the initial local position,
    //    So, it will move with its parent correctly
    Platform.prototype.update = function () {
        this.Horizontal_spike.setPosition(0, 30);
    };
    // ==============================
    // ========== TODO 1.1 ==========
    // 1. Define the action sequence.
    //    (Hint: you can use cc.sequence and cc.easeInOut to help you design actions.)
    // 2. Use moveDir to decide whether you should move vertical or horizontal.
    // 3. Let a variable action represent the "repeated action".
    //    (Hint: cc.repeatForever)
    // 4. Use schedule function to set the delay time when game start.
    Platform.prototype.platformMove = function (moveDir, delayTime, platform) {
        var action;
        var easeRate = 2;
        var sequence1 = cc.sequence(cc.moveBy(2, 0, 120).easing(cc.easeInOut(easeRate)), cc.moveBy(2, 0, -120).easing(cc.easeInOut(easeRate)));
        var sequence2 = cc.sequence(cc.moveBy(2, 120, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(2, -120, 0).easing(cc.easeInOut(easeRate)));
        if (moveDir == "vertical") {
            action = cc.repeatForever(sequence1);
        }
        else {
            action = cc.repeatForever(sequence2);
        }
        this.scheduleOnce(function () {
            platform.runAction(action);
        }, delayTime);
    };
    // ==============================
    Platform.prototype.spikeMove = function (delayTime, spike) {
        var action;
        var easeRate = 2;
        var sequence = cc.sequence(cc.moveBy(1, 40, 0).easing(cc.easeInOut(easeRate)), cc.moveBy(1, -40, 0).easing(cc.easeInOut(easeRate)));
        action = cc.repeatForever(sequence);
        this.scheduleOnce(function () {
            spike.runAction(action);
        }, delayTime);
    };
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Vertical_platform", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Horizontal_platform", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Vertical_spike", void 0);
    __decorate([
        property(cc.Node)
    ], Platform.prototype, "Horizontal_spike", void 0);
    Platform = __decorate([
        ccclass
    ], Platform);
    return Platform;
}(cc.Component));
exports.default = Platform;

cc._RF.pop();