"use strict";
cc._RF.push(module, 'bf68aCPzqtOyIpeTJZUELth', 'splitBirds');
// Scripts/splitBirds.ts

Object.defineProperty(exports, "__esModule", { value: true });
var bird_1 = require("./bird");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var split_bird = /** @class */ (function (_super) {
    __extends(split_bird, _super);
    function split_bird() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.draggable = true;
        _this.attachRope = true;
        _this.smokePrefabs = null;
        // ========== TODO 3.4 ==========
        // 1. Define bird's component.
        _this._bird = null;
        return _this;
    }
    // ==============================
    split_bird.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    // ========== TODO 3.5 ==========
    // 1. Get the bird's component from bird node when instantiated.
    split_bird.prototype.start = function () {
        this._bird = cc.find("Canvas/Slingshot/bird").getComponent(bird_1.bird);
    };
    // ==============================
    split_bird.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact");
            console.log(contact.getWorldManifold().points);
            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);
            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);
            this._bird.updateScore(30);
        }
        else if (other.tag == 2) { // game item tag
            console.log("Trigger");
            other.node.destroy();
            this._bird.updateScore(10);
        }
    };
    split_bird.prototype.onEndContact = function (contact, self, other) {
        if (other.tag == 1)
            other.tag = 0;
    };
    __decorate([
        property(cc.Prefab)
    ], split_bird.prototype, "smokePrefabs", void 0);
    __decorate([
        property(bird_1.bird)
    ], split_bird.prototype, "_bird", void 0);
    split_bird = __decorate([
        ccclass
    ], split_bird);
    return split_bird;
}(cc.Component));
exports.default = split_bird;

cc._RF.pop();