"use strict";
cc._RF.push(module, '92efah8QhRHmoYbLlzZWFB7', 'menu');
// Scripts/menu.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var menu = /** @class */ (function (_super) {
    __extends(menu, _super);
    function menu() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    menu.prototype.start = function () {
        var startbtn = new cc.Component.EventHandler();
        startbtn.target = this.node;
        startbtn.component = "menu";
        startbtn.handler = "loadGameScene";
        cc.find("Canvas/StartButton").getComponent(cc.Button).clickEvents.push(startbtn);
    };
    menu.prototype.loadGameScene = function () {
        cc.director.loadScene("main");
    };
    menu = __decorate([
        ccclass
    ], menu);
    return menu;
}(cc.Component));
exports.default = menu;

cc._RF.pop();