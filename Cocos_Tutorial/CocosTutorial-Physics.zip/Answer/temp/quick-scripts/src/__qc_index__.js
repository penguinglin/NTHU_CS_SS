
require('./assets/Scripts/GameManager');
require('./assets/Scripts/anchor');
require('./assets/Scripts/bird');
require('./assets/Scripts/menu');
require('./assets/migration/use_reversed_rotateTo');
