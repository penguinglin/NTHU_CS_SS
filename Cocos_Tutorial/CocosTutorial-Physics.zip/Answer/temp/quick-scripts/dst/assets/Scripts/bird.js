
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Scripts/bird.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6d012QIyy5FOLpzct9wIDzm', 'bird');
// Scripts/bird.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameManager_1 = require("./GameManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var bird = /** @class */ (function (_super) {
    __extends(bird, _super);
    function bird() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.draggable = true;
        _this.attachRope = true;
        _this.scorePoints = null;
        // ==============================
        _this.smokePrefabs = null;
        _this.GameMgr = null;
        return _this;
        // ==============================
    }
    bird.prototype.onLoad = function () {
        cc.director.getPhysicsManager().enabled = true;
    };
    bird.prototype.start = function () {
        this.initProperties();
        this.initResetButton();
        // ========== TODO 1.2 ==========
        // 1. Initialize the score to 0 when start.
        this.score = 0;
        // ==============================
    };
    bird.prototype.update = function () {
        var diff = this.initPos.sub(this.node.position);
        var angle = Math.atan2(diff.x, diff.y);
        if (this.node.position.sub(this.initPos).mag() <= 10) {
            if (!this.draggable) {
                this.motorJoint.enabled = false;
                this.ropeJoint.enabled = false;
                this.rb.angularVelocity = -angle * 20;
                this.attachRope = false;
                this.anchor1.setPosition(this.initPos.add(cc.v2(-20, 0)));
                this.anchor2.setPosition(this.initPos.add(cc.v2(-20, 0)));
            }
        }
        else {
            if (this.attachRope) {
                this.node.angle = -cc.misc.radiansToDegrees(angle) + 90;
                this.anchor1.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
                this.anchor2.setPosition(this.node.position.add(cc.v2(-18, 2).rotate(-angle + 90)));
            }
        }
    };
    bird.prototype.initProperties = function () {
        this.anchor1 = cc.find("Canvas/Slingshot/SlingshotFront/anchor1");
        this.anchor1.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.anchor2 = cc.find("Canvas/Slingshot/SlingshotBack/anchor2");
        this.anchor2.setPosition(this.node.position.add(cc.v2(-20, 0)));
        this.motorJoint = this.getComponent(cc.MotorJoint);
        this.ropeJoint = this.getComponent(cc.RopeJoint);
        this.rb = this.getComponent(cc.RigidBody);
        this.initPos = this.node.position;
        this.startPos = this.node.position;
        this.maxLength = this.ropeJoint.maxLength;
    };
    bird.prototype.initResetButton = function () {
        var clickEventHandler = new cc.Component.EventHandler();
        clickEventHandler.target = this.node;
        clickEventHandler.component = "bird";
        clickEventHandler.handler = "reset";
        cc.find("Canvas/Reset").getComponent(cc.Button).clickEvents.push(clickEventHandler);
    };
    bird.prototype.reset = function () {
        this.node.setPosition(this.initPos);
        this.rb.linearVelocity = cc.Vec2.ZERO;
        this.rb.angularVelocity = 0;
        this.rb.gravityScale = 0;
        this.node.angle = 0;
        this.draggable = true;
        this.attachRope = true;
    };
    bird.prototype.onEnable = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.on(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    };
    bird.prototype.onDisable = function () {
        this.node.off(cc.Node.EventType.TOUCH_START, this._onTouchBegan, this);
        this.node.off(cc.Node.EventType.TOUCH_MOVE, this._onTouchMove, this);
        this.node.off(cc.Node.EventType.TOUCH_END, this._onTouchEnded, this);
        this.node.off(cc.Node.EventType.TOUCH_CANCEL, this._onTouchCancel, this);
    };
    bird.prototype._onTouchBegan = function (event) {
        if (!this.enabledInHierarchy)
            return;
        if (this.draggable) {
            this.startPos = this.node.position;
            this.motorJoint.enabled = false;
            this.rb.gravityScale = 0;
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    };
    bird.prototype._onTouchMove = function (event) {
        if (!this.enabledInHierarchy)
            return;
        if (this.draggable) {
            var start = event.getStartLocation();
            var cur = event.getLocation();
            cur.subSelf(start);
            var cur_v = cc.v2(cur.x, cur.y);
            if (cur_v.mag() > this.maxLength) {
                cur_v.normalizeSelf().mulSelf(this.maxLength);
            }
            this.node.setPosition(this.startPos.add(cur_v));
            this.rb.linearVelocity = cc.Vec2.ZERO;
            this.rb.angularVelocity = 0;
        }
        event.stopPropagation();
    };
    bird.prototype._onTouchEnded = function (event) {
        if (!this.enabledInHierarchy)
            return;
        this.dragEnd();
        event.stopPropagation();
    };
    bird.prototype._onTouchCancel = function (event) {
        if (!this.enabledInHierarchy)
            return;
        this.dragEnd();
        event.stopPropagation();
    };
    bird.prototype.dragEnd = function () {
        if (!this.draggable)
            return;
        if (this.node.position.sub(this.startPos).mag() > 10) {
            this.draggable = false;
        }
        this.motorJoint.enabled = true;
        this.rb.gravityScale = 1;
        this.rb.linearVelocity = cc.v2(1, 0);
        this.GameMgr.playEffect();
    };
    // ========== TODO 1.3 ==========
    // 1. Add a function to update score point 
    // (Hint: You can use number.toString() function to convert number to string)
    bird.prototype.updateScore = function (number) {
        this.score += number;
        this.scorePoints.getComponent(cc.Label).string = this.score.toString();
    };
    // ==============================
    // ========== TODO 2.1 ==========
    // 1. Set up onBeginContact. (Hint: use tag to figure out which object we're contact with)
    // 2. if contact with pigs, then instantiate smoke prefab.
    //    2-1. Set the smokePrefabs's position same to position where they met.
    //    2-2. Use this.scheduleOnce to destroy smoke prefab after 1.5s.
    //    2-3. Add 30 points.
    bird.prototype.onBeginContact = function (contact, self, other) {
        if (other.tag == 1) { // enemy tag
            console.log("BeginContact");
            console.log(contact.getWorldManifold().points);
            var smoke = cc.instantiate(this.smokePrefabs);
            smoke.setPosition(contact.getWorldManifold().points[0]);
            cc.find("Canvas/Environment").addChild(smoke);
            this.scheduleOnce(function () {
                smoke.destroy();
            }, 1.5);
            this.updateScore(30);
        }
        // ==============================
        // =========== TODO 3 ===========
        // 1. if contact with item.
        //    1-1. Destroy the item.
        //    1-2. Add 10 points.
        else if (other.tag == 2) { // game item tag
            console.log("Trigger");
            other.node.destroy();
            this.updateScore(10);
        }
        // ==============================
    };
    // ========== TODO 2.2 ==========
    // 1. Set up onEndContact.
    // 2. Change the tag of pigs' in order not to instantiate smoke any more.
    bird.prototype.onEndContact = function (contact, self, other) {
        if (other.tag == 1)
            other.tag = 0;
    };
    __decorate([
        property(cc.Node)
    ], bird.prototype, "scorePoints", void 0);
    __decorate([
        property(cc.Prefab)
    ], bird.prototype, "smokePrefabs", void 0);
    __decorate([
        property(GameManager_1.GameManager)
    ], bird.prototype, "GameMgr", void 0);
    bird = __decorate([
        ccclass
    ], bird);
    return bird;
}(cc.Component));
exports.default = bird;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0c1xcYmlyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsNkNBQTRDO0FBRXRDLElBQUEsS0FBd0IsRUFBRSxDQUFDLFVBQVUsRUFBbkMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFrQixDQUFDO0FBRzVDO0lBQWtDLHdCQUFZO0lBQTlDO1FBQUEscUVBcVBDO1FBaFBHLGVBQVMsR0FBWSxJQUFJLENBQUM7UUFDMUIsZ0JBQVUsR0FBWSxJQUFJLENBQUM7UUFnQjNCLGlCQUFXLEdBQUcsSUFBSSxDQUFDO1FBQ25CLGlDQUFpQztRQUdqQyxrQkFBWSxHQUFjLElBQUksQ0FBQztRQUcvQixhQUFPLEdBQWdCLElBQUksQ0FBQzs7UUFxTjVCLGlDQUFpQztJQUdyQyxDQUFDO0lBdE5HLHFCQUFNLEdBQU47UUFDSSxFQUFFLENBQUMsUUFBUSxDQUFDLGlCQUFpQixFQUFFLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztJQUNuRCxDQUFDO0lBRUQsb0JBQUssR0FBTDtRQUNJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN0QixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDdkIsaUNBQWlDO1FBQ2pDLDJDQUEyQztRQUMzQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNmLGlDQUFpQztJQUNyQyxDQUFDO0lBR0QscUJBQU0sR0FBTjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEQsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2QyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQ2xELElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNqQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztnQkFDL0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO2dCQUN0QyxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztnQkFDeEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzFELElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzdEO1NBQ0o7YUFBTTtZQUNILElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFFekQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDcEYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN2RjtTQUNKO0lBQ0wsQ0FBQztJQUVELDZCQUFjLEdBQWQ7UUFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMseUNBQXlDLENBQUMsQ0FBQztRQUNsRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEUsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWhFLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTFDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDbEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUVuQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFFRCw4QkFBZSxHQUFmO1FBQ0ksSUFBSSxpQkFBaUIsR0FBRyxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEQsaUJBQWlCLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDckMsaUJBQWlCLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQztRQUNyQyxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBRXBDLEVBQUUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDeEYsQ0FBQztJQUVELG9CQUFLLEdBQUw7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFcEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1FBQzVCLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztRQUV6QixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDdEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDM0IsQ0FBQztJQUVELHVCQUFRLEdBQVI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNwRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQsd0JBQVMsR0FBVDtRQUNJLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFFRCw0QkFBYSxHQUFiLFVBQWMsS0FBSztRQUNmLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCO1lBQUUsT0FBTztRQUVyQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7WUFDaEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQ3pCLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3RDLElBQUksQ0FBQyxFQUFFLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQztTQUMvQjtRQUNELEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQsMkJBQVksR0FBWixVQUFhLEtBQUs7UUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQjtZQUFFLE9BQU87UUFFckMsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ2hCLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3JDLElBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM5QixHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRW5CLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEMsSUFBSSxLQUFLLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDOUIsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7YUFDakQ7WUFFRCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBRWhELElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3RDLElBQUksQ0FBQyxFQUFFLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQztTQUMvQjtRQUVELEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBRUQsNEJBQWEsR0FBYixVQUFjLEtBQUs7UUFDZixJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQjtZQUFFLE9BQU87UUFFckMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBRWYsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCw2QkFBYyxHQUFkLFVBQWUsS0FBSztRQUNoQixJQUFJLENBQUMsSUFBSSxDQUFDLGtCQUFrQjtZQUFFLE9BQU87UUFFckMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBRWYsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxzQkFBTyxHQUFQO1FBQ0ksSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTO1lBQUUsT0FBTztRQUU1QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQ2xELElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1NBQzFCO1FBRUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBRS9CLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztRQUN6QixJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUdyQyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBRTlCLENBQUM7SUFFRCxpQ0FBaUM7SUFDakMsMkNBQTJDO0lBQzNDLDZFQUE2RTtJQUM3RSwwQkFBVyxHQUFYLFVBQVksTUFBTTtRQUNkLElBQUksQ0FBQyxLQUFLLElBQUksTUFBTSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUMzRSxDQUFDO0lBQ0QsaUNBQWlDO0lBR2pDLGlDQUFpQztJQUNqQywwRkFBMEY7SUFDMUYsMERBQTBEO0lBQzFELDJFQUEyRTtJQUMzRSxvRUFBb0U7SUFDcEUseUJBQXlCO0lBRXpCLDZCQUFjLEdBQWQsVUFBZSxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUs7UUFDL0IsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUFFLFlBQVk7WUFDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQTtZQUMzQixPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRS9DLElBQUksS0FBSyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQzlDLEtBQUssQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFeEQsRUFBRSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM5QyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNkLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNwQixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFFUixJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3hCO1FBQ0wsaUNBQWlDO1FBRTdCLGlDQUFpQztRQUNqQywyQkFBMkI7UUFDM0IsNEJBQTRCO1FBQzVCLHlCQUF5QjthQUNwQixJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCO1lBRXZDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFFdkIsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3hCO1FBQ0QsaUNBQWlDO0lBQ3JDLENBQUM7SUFJRCxpQ0FBaUM7SUFDakMsMEJBQTBCO0lBQzFCLHlFQUF5RTtJQUN6RSwyQkFBWSxHQUFaLFVBQWEsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLO1FBQzdCLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQUUsS0FBSyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQTNORDtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDOzZDQUNDO0lBSW5CO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7OENBQ1c7SUFHL0I7UUFEQyxRQUFRLENBQUMseUJBQVcsQ0FBQzt5Q0FDTTtJQTdCWCxJQUFJO1FBRHhCLE9BQU87T0FDYSxJQUFJLENBcVB4QjtJQUFELFdBQUM7Q0FyUEQsQUFxUEMsQ0FyUGlDLEVBQUUsQ0FBQyxTQUFTLEdBcVA3QztrQkFyUG9CLElBQUkiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgR2FtZU1hbmFnZXIgfSBmcm9tIFwiLi9HYW1lTWFuYWdlclwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIGJpcmQgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG5cclxuICAgIGFuY2hvcjE6IGNjLk5vZGU7XHJcbiAgICBhbmNob3IyOiBjYy5Ob2RlO1xyXG5cclxuICAgIGRyYWdnYWJsZTogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBhdHRhY2hSb3BlOiBib29sZWFuID0gdHJ1ZTtcclxuXHJcbiAgICBpbml0UG9zOiBjYy5WZWMyO1xyXG4gICAgc3RhcnRQb3M6IGNjLlZlYzI7XHJcblxyXG4gICAgbW90b3JKb2ludDogY2MuTW90b3JKb2ludDtcclxuICAgIHJvcGVKb2ludDogY2MuUm9wZUpvaW50O1xyXG4gICAgcmI6IGNjLlJpZ2lkQm9keTtcclxuXHJcbiAgICBtYXhMZW5ndGg6IG51bWJlcjtcclxuXHJcbiAgICAvLyA9PT09PT09PT09IFRPRE8gMS4xID09PT09PT09PT1cclxuICAgIC8vIDEuIERlZmluZSBzY29yZSByZWxhdGVkIHByb3BlcnR5LlxyXG4gICAgc2NvcmU6IG51bWJlcjtcclxuXHJcbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcclxuICAgIHNjb3JlUG9pbnRzID0gbnVsbDtcclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuICAgIEBwcm9wZXJ0eShjYy5QcmVmYWIpXHJcbiAgICBzbW9rZVByZWZhYnM6IGNjLlByZWZhYiA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KEdhbWVNYW5hZ2VyKVxyXG4gICAgR2FtZU1ncjogR2FtZU1hbmFnZXIgPSBudWxsO1xyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjYy5kaXJlY3Rvci5nZXRQaHlzaWNzTWFuYWdlcigpLmVuYWJsZWQgPSB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuaW5pdFByb3BlcnRpZXMoKTtcclxuICAgICAgICB0aGlzLmluaXRSZXNldEJ1dHRvbigpO1xyXG4gICAgICAgIC8vID09PT09PT09PT0gVE9ETyAxLjIgPT09PT09PT09PVxyXG4gICAgICAgIC8vIDEuIEluaXRpYWxpemUgdGhlIHNjb3JlIHRvIDAgd2hlbiBzdGFydC5cclxuICAgICAgICB0aGlzLnNjb3JlID0gMDtcclxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIH1cclxuXHJcblxyXG4gICAgdXBkYXRlKCkge1xyXG4gICAgICAgIHZhciBkaWZmID0gdGhpcy5pbml0UG9zLnN1Yih0aGlzLm5vZGUucG9zaXRpb24pO1xyXG4gICAgICAgIHZhciBhbmdsZSA9IE1hdGguYXRhbjIoZGlmZi54LCBkaWZmLnkpO1xyXG4gICAgICAgIGlmICh0aGlzLm5vZGUucG9zaXRpb24uc3ViKHRoaXMuaW5pdFBvcykubWFnKCkgPD0gMTApIHtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLmRyYWdnYWJsZSkge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5tb3RvckpvaW50LmVuYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucm9wZUpvaW50LmVuYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMucmIuYW5ndWxhclZlbG9jaXR5ID0gLWFuZ2xlICogMjA7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmF0dGFjaFJvcGUgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYW5jaG9yMS5zZXRQb3NpdGlvbih0aGlzLmluaXRQb3MuYWRkKGNjLnYyKC0yMCwgMCkpKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuYW5jaG9yMi5zZXRQb3NpdGlvbih0aGlzLmluaXRQb3MuYWRkKGNjLnYyKC0yMCwgMCkpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmF0dGFjaFJvcGUpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMubm9kZS5hbmdsZSA9IC0gY2MubWlzYy5yYWRpYW5zVG9EZWdyZWVzKGFuZ2xlKSArIDkwO1xyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuYW5jaG9yMS5zZXRQb3NpdGlvbih0aGlzLm5vZGUucG9zaXRpb24uYWRkKGNjLnYyKC0xOCwgMikucm90YXRlKC1hbmdsZSArIDkwKSkpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5hbmNob3IyLnNldFBvc2l0aW9uKHRoaXMubm9kZS5wb3NpdGlvbi5hZGQoY2MudjIoLTE4LCAyKS5yb3RhdGUoLWFuZ2xlICsgOTApKSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaW5pdFByb3BlcnRpZXMoKSB7XHJcbiAgICAgICAgdGhpcy5hbmNob3IxID0gY2MuZmluZChcIkNhbnZhcy9TbGluZ3Nob3QvU2xpbmdzaG90RnJvbnQvYW5jaG9yMVwiKTtcclxuICAgICAgICB0aGlzLmFuY2hvcjEuc2V0UG9zaXRpb24odGhpcy5ub2RlLnBvc2l0aW9uLmFkZChjYy52MigtMjAsIDApKSk7XHJcbiAgICAgICAgdGhpcy5hbmNob3IyID0gY2MuZmluZChcIkNhbnZhcy9TbGluZ3Nob3QvU2xpbmdzaG90QmFjay9hbmNob3IyXCIpO1xyXG4gICAgICAgIHRoaXMuYW5jaG9yMi5zZXRQb3NpdGlvbih0aGlzLm5vZGUucG9zaXRpb24uYWRkKGNjLnYyKC0yMCwgMCkpKTtcclxuXHJcbiAgICAgICAgdGhpcy5tb3RvckpvaW50ID0gdGhpcy5nZXRDb21wb25lbnQoY2MuTW90b3JKb2ludCk7XHJcbiAgICAgICAgdGhpcy5yb3BlSm9pbnQgPSB0aGlzLmdldENvbXBvbmVudChjYy5Sb3BlSm9pbnQpO1xyXG4gICAgICAgIHRoaXMucmIgPSB0aGlzLmdldENvbXBvbmVudChjYy5SaWdpZEJvZHkpO1xyXG5cclxuICAgICAgICB0aGlzLmluaXRQb3MgPSB0aGlzLm5vZGUucG9zaXRpb247XHJcbiAgICAgICAgdGhpcy5zdGFydFBvcyA9IHRoaXMubm9kZS5wb3NpdGlvbjtcclxuXHJcbiAgICAgICAgdGhpcy5tYXhMZW5ndGggPSB0aGlzLnJvcGVKb2ludC5tYXhMZW5ndGg7XHJcbiAgICB9XHJcblxyXG4gICAgaW5pdFJlc2V0QnV0dG9uKCkge1xyXG4gICAgICAgIGxldCBjbGlja0V2ZW50SGFuZGxlciA9IG5ldyBjYy5Db21wb25lbnQuRXZlbnRIYW5kbGVyKCk7XHJcbiAgICAgICAgY2xpY2tFdmVudEhhbmRsZXIudGFyZ2V0ID0gdGhpcy5ub2RlO1xyXG4gICAgICAgIGNsaWNrRXZlbnRIYW5kbGVyLmNvbXBvbmVudCA9IFwiYmlyZFwiO1xyXG4gICAgICAgIGNsaWNrRXZlbnRIYW5kbGVyLmhhbmRsZXIgPSBcInJlc2V0XCI7XHJcblxyXG4gICAgICAgIGNjLmZpbmQoXCJDYW52YXMvUmVzZXRcIikuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbikuY2xpY2tFdmVudHMucHVzaChjbGlja0V2ZW50SGFuZGxlcik7XHJcbiAgICB9XHJcblxyXG4gICAgcmVzZXQoKSB7XHJcbiAgICAgICAgdGhpcy5ub2RlLnNldFBvc2l0aW9uKHRoaXMuaW5pdFBvcyk7XHJcblxyXG4gICAgICAgIHRoaXMucmIubGluZWFyVmVsb2NpdHkgPSBjYy5WZWMyLlpFUk87XHJcbiAgICAgICAgdGhpcy5yYi5hbmd1bGFyVmVsb2NpdHkgPSAwO1xyXG4gICAgICAgIHRoaXMucmIuZ3Jhdml0eVNjYWxlID0gMDtcclxuXHJcbiAgICAgICAgdGhpcy5ub2RlLmFuZ2xlID0gMDtcclxuICAgICAgICB0aGlzLmRyYWdnYWJsZSA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5hdHRhY2hSb3BlID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBvbkVuYWJsZSgpIHtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMuX29uVG91Y2hCZWdhbiwgdGhpcyk7XHJcbiAgICAgICAgdGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMuX29uVG91Y2hNb3ZlLCB0aGlzKTtcclxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLl9vblRvdWNoRW5kZWQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9DQU5DRUwsIHRoaXMuX29uVG91Y2hDYW5jZWwsIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uRGlzYWJsZSgpIHtcclxuICAgICAgICB0aGlzLm5vZGUub2ZmKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLl9vblRvdWNoQmVnYW4sIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5fb25Ub3VjaE1vdmUsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLl9vblRvdWNoRW5kZWQsIHRoaXMpO1xyXG4gICAgICAgIHRoaXMubm9kZS5vZmYoY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfQ0FOQ0VMLCB0aGlzLl9vblRvdWNoQ2FuY2VsLCB0aGlzKTtcclxuICAgIH1cclxuXHJcbiAgICBfb25Ub3VjaEJlZ2FuKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWRJbkhpZXJhcmNoeSkgcmV0dXJuO1xyXG5cclxuICAgICAgICBpZiAodGhpcy5kcmFnZ2FibGUpIHtcclxuICAgICAgICAgICAgdGhpcy5zdGFydFBvcyA9IHRoaXMubm9kZS5wb3NpdGlvbjtcclxuICAgICAgICAgICAgdGhpcy5tb3RvckpvaW50LmVuYWJsZWQgPSBmYWxzZTtcclxuICAgICAgICAgICAgdGhpcy5yYi5ncmF2aXR5U2NhbGUgPSAwO1xyXG4gICAgICAgICAgICB0aGlzLnJiLmxpbmVhclZlbG9jaXR5ID0gY2MuVmVjMi5aRVJPO1xyXG4gICAgICAgICAgICB0aGlzLnJiLmFuZ3VsYXJWZWxvY2l0eSA9IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIF9vblRvdWNoTW92ZShldmVudCkge1xyXG4gICAgICAgIGlmICghdGhpcy5lbmFibGVkSW5IaWVyYXJjaHkpIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKHRoaXMuZHJhZ2dhYmxlKSB7XHJcbiAgICAgICAgICAgIGxldCBzdGFydCA9IGV2ZW50LmdldFN0YXJ0TG9jYXRpb24oKTtcclxuICAgICAgICAgICAgbGV0IGN1ciA9IGV2ZW50LmdldExvY2F0aW9uKCk7XHJcbiAgICAgICAgICAgIGN1ci5zdWJTZWxmKHN0YXJ0KTtcclxuXHJcbiAgICAgICAgICAgIGxldCBjdXJfdiA9IGNjLnYyKGN1ci54LCBjdXIueSk7XHJcbiAgICAgICAgICAgIGlmIChjdXJfdi5tYWcoKSA+IHRoaXMubWF4TGVuZ3RoKSB7XHJcbiAgICAgICAgICAgICAgICBjdXJfdi5ub3JtYWxpemVTZWxmKCkubXVsU2VsZih0aGlzLm1heExlbmd0aCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRoaXMubm9kZS5zZXRQb3NpdGlvbih0aGlzLnN0YXJ0UG9zLmFkZChjdXJfdikpO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5yYi5saW5lYXJWZWxvY2l0eSA9IGNjLlZlYzIuWkVSTztcclxuICAgICAgICAgICAgdGhpcy5yYi5hbmd1bGFyVmVsb2NpdHkgPSAwO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgX29uVG91Y2hFbmRlZChldmVudCkge1xyXG4gICAgICAgIGlmICghdGhpcy5lbmFibGVkSW5IaWVyYXJjaHkpIHJldHVybjtcclxuXHJcbiAgICAgICAgdGhpcy5kcmFnRW5kKCk7XHJcblxyXG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgfVxyXG5cclxuICAgIF9vblRvdWNoQ2FuY2VsKGV2ZW50KSB7XHJcbiAgICAgICAgaWYgKCF0aGlzLmVuYWJsZWRJbkhpZXJhcmNoeSkgcmV0dXJuO1xyXG5cclxuICAgICAgICB0aGlzLmRyYWdFbmQoKTtcclxuXHJcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICB9XHJcblxyXG4gICAgZHJhZ0VuZCgpIHtcclxuICAgICAgICBpZiAoIXRoaXMuZHJhZ2dhYmxlKSByZXR1cm47XHJcblxyXG4gICAgICAgIGlmICh0aGlzLm5vZGUucG9zaXRpb24uc3ViKHRoaXMuc3RhcnRQb3MpLm1hZygpID4gMTApIHtcclxuICAgICAgICAgICAgdGhpcy5kcmFnZ2FibGUgPSBmYWxzZTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMubW90b3JKb2ludC5lbmFibGVkID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgdGhpcy5yYi5ncmF2aXR5U2NhbGUgPSAxO1xyXG4gICAgICAgIHRoaXMucmIubGluZWFyVmVsb2NpdHkgPSBjYy52MigxLCAwKTtcclxuXHJcblxyXG4gICAgICAgIHRoaXMuR2FtZU1nci5wbGF5RWZmZWN0KCk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8vID09PT09PT09PT0gVE9ETyAxLjMgPT09PT09PT09PVxyXG4gICAgLy8gMS4gQWRkIGEgZnVuY3Rpb24gdG8gdXBkYXRlIHNjb3JlIHBvaW50IFxyXG4gICAgLy8gKEhpbnQ6IFlvdSBjYW4gdXNlIG51bWJlci50b1N0cmluZygpIGZ1bmN0aW9uIHRvIGNvbnZlcnQgbnVtYmVyIHRvIHN0cmluZylcclxuICAgIHVwZGF0ZVNjb3JlKG51bWJlcikge1xyXG4gICAgICAgIHRoaXMuc2NvcmUgKz0gbnVtYmVyO1xyXG4gICAgICAgIHRoaXMuc2NvcmVQb2ludHMuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSB0aGlzLnNjb3JlLnRvU3RyaW5nKCk7XHJcbiAgICB9XHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuXHJcblxyXG4gICAgLy8gPT09PT09PT09PSBUT0RPIDIuMSA9PT09PT09PT09XHJcbiAgICAvLyAxLiBTZXQgdXAgb25CZWdpbkNvbnRhY3QuIChIaW50OiB1c2UgdGFnIHRvIGZpZ3VyZSBvdXQgd2hpY2ggb2JqZWN0IHdlJ3JlIGNvbnRhY3Qgd2l0aClcclxuICAgIC8vIDIuIGlmIGNvbnRhY3Qgd2l0aCBwaWdzLCB0aGVuIGluc3RhbnRpYXRlIHNtb2tlIHByZWZhYi5cclxuICAgIC8vICAgIDItMS4gU2V0IHRoZSBzbW9rZVByZWZhYnMncyBwb3NpdGlvbiBzYW1lIHRvIHBvc2l0aW9uIHdoZXJlIHRoZXkgbWV0LlxyXG4gICAgLy8gICAgMi0yLiBVc2UgdGhpcy5zY2hlZHVsZU9uY2UgdG8gZGVzdHJveSBzbW9rZSBwcmVmYWIgYWZ0ZXIgMS41cy5cclxuICAgIC8vICAgIDItMy4gQWRkIDMwIHBvaW50cy5cclxuXHJcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikge1xyXG4gICAgICAgIGlmIChvdGhlci50YWcgPT0gMSkgeyAvLyBlbmVteSB0YWdcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJCZWdpbkNvbnRhY3RcIilcclxuICAgICAgICAgICAgY29uc29sZS5sb2coY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCkucG9pbnRzKTtcclxuXHJcbiAgICAgICAgICAgIHZhciBzbW9rZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuc21va2VQcmVmYWJzKTtcclxuICAgICAgICAgICAgc21va2Uuc2V0UG9zaXRpb24oY29udGFjdC5nZXRXb3JsZE1hbmlmb2xkKCkucG9pbnRzWzBdKTtcclxuXHJcbiAgICAgICAgICAgIGNjLmZpbmQoXCJDYW52YXMvRW52aXJvbm1lbnRcIikuYWRkQ2hpbGQoc21va2UpO1xyXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgICAgICBzbW9rZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIH0sIDEuNSk7XHJcblxyXG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVNjb3JlKDMwKTtcclxuICAgICAgICB9IFxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4gICAgICAgIC8vID09PT09PT09PT09IFRPRE8gMyA9PT09PT09PT09PVxyXG4gICAgICAgIC8vIDEuIGlmIGNvbnRhY3Qgd2l0aCBpdGVtLlxyXG4gICAgICAgIC8vICAgIDEtMS4gRGVzdHJveSB0aGUgaXRlbS5cclxuICAgICAgICAvLyAgICAxLTIuIEFkZCAxMCBwb2ludHMuXHJcbiAgICAgICAgZWxzZSBpZiAob3RoZXIudGFnID09IDIpIHsgLy8gZ2FtZSBpdGVtIHRhZ1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJUcmlnZ2VyXCIpO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgb3RoZXIubm9kZS5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgIHRoaXMudXBkYXRlU2NvcmUoMTApO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8vID09PT09PT09PT0gVE9ETyAyLjIgPT09PT09PT09PVxyXG4gICAgLy8gMS4gU2V0IHVwIG9uRW5kQ29udGFjdC5cclxuICAgIC8vIDIuIENoYW5nZSB0aGUgdGFnIG9mIHBpZ3MnIGluIG9yZGVyIG5vdCB0byBpbnN0YW50aWF0ZSBzbW9rZSBhbnkgbW9yZS5cclxuICAgIG9uRW5kQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikge1xyXG4gICAgICAgIGlmIChvdGhlci50YWcgPT0gMSkgb3RoZXIudGFnID0gMDtcclxuICAgIH1cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG5cclxuXHJcbn1cclxuIl19