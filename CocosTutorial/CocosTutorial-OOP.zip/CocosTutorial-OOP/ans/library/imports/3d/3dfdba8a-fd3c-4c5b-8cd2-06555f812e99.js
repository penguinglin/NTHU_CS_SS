"use strict";
cc._RF.push(module, '3dfdbqK/TxMW4zSBlVfgS6Z', 'ActorController');
// scripts/ActorController.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var Controller_1 = require("./input/Controller");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var FacingDirection;
(function (FacingDirection) {
    FacingDirection[FacingDirection["Right"] = 0] = "Right";
    FacingDirection[FacingDirection["Left"] = 1] = "Left";
})(FacingDirection || (FacingDirection = {}));
function sign(x) {
    return x > 0 ? 1 : x < 0 ? -1 : 0;
}
/**
 * A component that implements movement and actions for each actor.
 * Toggle "Use Player Input" to read from player input.
 */
var ActorController = /** @class */ (function (_super) {
    __extends(ActorController, _super);
    function ActorController() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.initialFacingDirection = FacingDirection.Right;
        _this._animation = null;
        _this._animState = null;
        _this._rigidbody = null;
        _this.idleAnimationName = "";
        _this.moveAnimationName = "";
        _this._idleAnimState = null;
        _this._moveAnimState = null;
        _this.moveSpeed = 10;
        _this.moveAxisX = 0;
        _this.moveAxisY = 0;
        return _this;
    }
    Object.defineProperty(ActorController.prototype, "moveAxis2D", {
        get: function () {
            return new cc.Vec2(this.moveAxisX, this.moveAxisY);
        },
        enumerable: false,
        configurable: true
    });
    // LIFE-CYCLE CALLBACKS:
    ActorController.prototype.onLoad = function () {
        this._animation = this.node.getComponent(cc.Animation);
        if (!this._animation)
            console.warn("ActorController: Component cc.Animation missing on node " + this.node.name);
        this._rigidbody = this.node.getComponent(cc.RigidBody);
        if (!this._rigidbody)
            console.warn("ActorController: Component cc.Rigidbody missing on node " + this.node.name);
    };
    ActorController.prototype.start = function () {
        _super.prototype.start.call(this);
        this._idleAnimState = this._animation.getAnimationState(this.idleAnimationName);
        this._moveAnimState = this._animation.getAnimationState(this.moveAnimationName);
        this._animState = this._animation.play(this.idleAnimationName);
    };
    ActorController.prototype.update = function (dt) {
        // Receive external input if available.
        if (this.inputSource) {
            this.moveAxisX = this.inputSource.horizontalAxis;
            this.moveAxisY = this.inputSource.verticalAxis;
        }
        this._rigidbody.linearVelocity = this.moveAxis2D.mul(this.moveSpeed * dt);
        if (!this._rigidbody.linearVelocity.fuzzyEquals(cc.Vec2.ZERO, 0.01)) {
            if (this._animState != this._moveAnimState) {
                this._animState = this._animation.play(this.moveAnimationName);
            }
            if (this.moveAxisX != 0) {
                this.node.setScale(new cc.Vec2(
                // X
                this.initialFacingDirection == FacingDirection.Right ?
                    sign(this.moveAxisX) :
                    -sign(this.moveAxisX), 
                // Y
                1));
            }
        }
        else {
            if (this._animState != this._idleAnimState) {
                this._animState = this._animation.play(this.idleAnimationName);
            }
        }
        this.node.position = this.node.position.add(this._rigidbody.linearVelocity);
    };
    __decorate([
        property({ type: cc.Enum(FacingDirection) })
    ], ActorController.prototype, "initialFacingDirection", void 0);
    __decorate([
        property(cc.String)
    ], ActorController.prototype, "idleAnimationName", void 0);
    __decorate([
        property(cc.String)
    ], ActorController.prototype, "moveAnimationName", void 0);
    __decorate([
        property(cc.Float)
    ], ActorController.prototype, "moveSpeed", void 0);
    ActorController = __decorate([
        ccclass
    ], ActorController);
    return ActorController;
}(Controller_1.default));
exports.default = ActorController;

cc._RF.pop();