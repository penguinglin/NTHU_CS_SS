
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/input/IInputControls.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5cb1e/x681EIqL7dYrX+sTd', 'IInputControls');
// scripts/input/IInputControls.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.hasImplementedInputControls = exports.ButtonState = void 0;
/**
 * The state of a button-like variable during a single frame.
 */
var ButtonState;
(function (ButtonState) {
    /** The button is in its natural (inactive) state. */
    ButtonState[ButtonState["Rest"] = 0] = "Rest";
    /** The button is pressed down this frame. */
    ButtonState[ButtonState["Pressed"] = 1] = "Pressed";
    /** The button is held down. */
    ButtonState[ButtonState["Held"] = 2] = "Held";
    /** The button is released this frame. */
    ButtonState[ButtonState["Released"] = 3] = "Released";
})(ButtonState = exports.ButtonState || (exports.ButtonState = {}));
function hasImplementedInputControls(obj) {
    return obj &&
        (obj.horizontalAxis !== undefined) &&
        (obj.verticalAxis !== undefined) &&
        (obj.attack !== undefined) &&
        (obj.interact !== undefined);
}
exports.hasImplementedInputControls = hasImplementedInputControls;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcaW5wdXRcXElJbnB1dENvbnRyb2xzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7O0dBRUc7QUFDSCxJQUFZLFdBU1g7QUFURCxXQUFZLFdBQVc7SUFDbkIscURBQXFEO0lBQ3JELDZDQUFJLENBQUE7SUFDSiw2Q0FBNkM7SUFDN0MsbURBQU8sQ0FBQTtJQUNQLCtCQUErQjtJQUMvQiw2Q0FBSSxDQUFBO0lBQ0oseUNBQXlDO0lBQ3pDLHFEQUFRLENBQUE7QUFDWixDQUFDLEVBVFcsV0FBVyxHQUFYLG1CQUFXLEtBQVgsbUJBQVcsUUFTdEI7QUFhRCxTQUFnQiwyQkFBMkIsQ0FBQyxHQUFRO0lBQ2hELE9BQU8sR0FBRztRQUNWLENBQUMsR0FBRyxDQUFDLGNBQWMsS0FBSyxTQUFTLENBQUM7UUFDbEMsQ0FBQyxHQUFHLENBQUMsWUFBWSxLQUFLLFNBQVMsQ0FBQztRQUNoQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDO1FBQzFCLENBQUMsR0FBRyxDQUFDLFFBQVEsS0FBSyxTQUFTLENBQUMsQ0FBQTtBQUNoQyxDQUFDO0FBTkQsa0VBTUMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLyoqXHJcbiAqIFRoZSBzdGF0ZSBvZiBhIGJ1dHRvbi1saWtlIHZhcmlhYmxlIGR1cmluZyBhIHNpbmdsZSBmcmFtZS5cclxuICovXHJcbmV4cG9ydCBlbnVtIEJ1dHRvblN0YXRle1xyXG4gICAgLyoqIFRoZSBidXR0b24gaXMgaW4gaXRzIG5hdHVyYWwgKGluYWN0aXZlKSBzdGF0ZS4gKi9cclxuICAgIFJlc3QsXHJcbiAgICAvKiogVGhlIGJ1dHRvbiBpcyBwcmVzc2VkIGRvd24gdGhpcyBmcmFtZS4gKi9cclxuICAgIFByZXNzZWQsXHJcbiAgICAvKiogVGhlIGJ1dHRvbiBpcyBoZWxkIGRvd24uICovXHJcbiAgICBIZWxkLFxyXG4gICAgLyoqIFRoZSBidXR0b24gaXMgcmVsZWFzZWQgdGhpcyBmcmFtZS4gKi9cclxuICAgIFJlbGVhc2VkLFxyXG59XHJcbmV4cG9ydCB0eXBlIEF4aXMxRCA9IG51bWJlcjtcclxuLyoqXHJcbiAqIEludGVyZmFjZSBmb3Igb2JqZWN0cyB0aGF0IGNhbiBzdXBwb3J0IGNvbnRyb2wgaW5wdXRzLlxyXG4gKiBZb3UgY2FuIGNvbnNpZGVyIHRoaXMgYXMgYW4gYWJzdHJhY3Rpb24gb3ZlciBkaWZmZXJlbnQga2luZHMgb2YgaW5wdXRzLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBJSW5wdXRDb250cm9scyB7XHJcbiAgICByZWFkb25seSBob3Jpem9udGFsQXhpczogQXhpczFEO1xyXG4gICAgcmVhZG9ubHkgdmVydGljYWxBeGlzOiBBeGlzMUQ7XHJcbiAgICByZWFkb25seSBhdHRhY2s6IEJ1dHRvblN0YXRlO1xyXG4gICAgcmVhZG9ubHkgaW50ZXJhY3Q6IEJ1dHRvblN0YXRlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaGFzSW1wbGVtZW50ZWRJbnB1dENvbnRyb2xzKG9iajogYW55KTogb2JqIGlzIElJbnB1dENvbnRyb2xze1xyXG4gICAgcmV0dXJuIG9iaiAmJiBcclxuICAgIChvYmouaG9yaXpvbnRhbEF4aXMgIT09IHVuZGVmaW5lZCkgJiZcclxuICAgIChvYmoudmVydGljYWxBeGlzICE9PSB1bmRlZmluZWQpICYmXHJcbiAgICAob2JqLmF0dGFjayAhPT0gdW5kZWZpbmVkKSAmJlxyXG4gICAgKG9iai5pbnRlcmFjdCAhPT0gdW5kZWZpbmVkKVxyXG59Il19