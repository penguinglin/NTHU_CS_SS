
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/Coward.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0f1e55DmctOVp8eQg/uquO9', 'Coward');
// scripts/ai/strategies/Coward.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.Coward = void 0;
var AgentStrategy_1 = require("./AgentStrategy");
var Coward = /** @class */ (function (_super) {
    __extends(Coward, _super);
    /**
     *
     * @param _agent The agent using the strategy.
     * @param _runAwayFrom The node for the agent to run away from.
     */
    function Coward(_agent, _runAwayFrom) {
        var _this = _super.call(this) || this;
        _this._agent = null;
        _this._runAwayFrom = null;
        _this._moveAxis2D = cc.Vec2.ZERO;
        _this._agent = _agent;
        _this._runAwayFrom = _runAwayFrom;
        return _this;
    }
    Object.defineProperty(Coward.prototype, "awayFromTarget", {
        get: function () {
            return this._agent.node.position.sub(this._runAwayFrom.position).normalize();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "distanceFromTarget", {
        get: function () {
            return this._runAwayFrom.position.sub(this._agent.node.position).mag();
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "horizontalAxis", {
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Coward.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Coward.prototype.start = function () {
    };
    Coward.prototype.update = function (dt) {
        this._moveAxis2D = this.awayFromTarget;
    };
    return Coward;
}(AgentStrategy_1.AI.Strategy));
exports.Coward = Coward;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXENvd2FyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLGlEQUFxQztBQUVyQztJQUE0QiwwQkFBVztJQUduQzs7OztPQUlHO0lBQ0gsZ0JBQVksTUFBYSxFQUFFLFlBQXFCO1FBQWhELFlBQ0ksaUJBQU8sU0FHVjtRQVhPLFlBQU0sR0FBVSxJQUFJLENBQUM7UUFDckIsa0JBQVksR0FBWSxJQUFJLENBQUM7UUFZN0IsaUJBQVcsR0FBWSxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUp4QyxLQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNyQixLQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQzs7SUFDckMsQ0FBQztJQUlELHNCQUFXLGtDQUFjO2FBQXpCO1lBQ0ksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDakYsQ0FBQzs7O09BQUE7SUFFRCxzQkFBVyxzQ0FBa0I7YUFBN0I7WUFDSSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUMxRSxDQUFDOzs7T0FBQTtJQUVELHNCQUFXLGtDQUFjO2FBQXpCO1lBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUNELHNCQUFXLGdDQUFZO2FBQXZCO1lBQ0ksT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUM5QixDQUFDOzs7T0FBQTtJQUNELHNCQUFXLDBCQUFNO2FBQWpCO1lBQ0ksTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1FBQy9DLENBQUM7OztPQUFBO0lBQ0Qsc0JBQVcsNEJBQVE7YUFBbkI7WUFDSSxNQUFNLElBQUksS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUM7UUFDL0MsQ0FBQzs7O09BQUE7SUFDTSxzQkFBSyxHQUFaO0lBRUEsQ0FBQztJQUNNLHVCQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUMzQyxDQUFDO0lBRUwsYUFBQztBQUFELENBM0NBLEFBMkNDLENBM0MyQixrQkFBRSxDQUFDLFFBQVEsR0EyQ3RDO0FBM0NZLHdCQUFNIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uU3RhdGUgfSBmcm9tIFwiLi4vLi4vaW5wdXQvSUlucHV0Q29udHJvbHNcIjtcclxuaW1wb3J0IEFnZW50IGZyb20gXCIuLi9BZ2VudFwiO1xyXG5pbXBvcnQgeyBBSSB9IGZyb20gXCIuL0FnZW50U3RyYXRlZ3lcIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBDb3dhcmQgZXh0ZW5kcyBBSS5TdHJhdGVneXtcclxuICAgIHByaXZhdGUgX2FnZW50OiBBZ2VudCA9IG51bGw7XHJcbiAgICBwcml2YXRlIF9ydW5Bd2F5RnJvbTogY2MuTm9kZSA9IG51bGw7XHJcbiAgICAvKipcclxuICAgICAqIFxyXG4gICAgICogQHBhcmFtIF9hZ2VudCBUaGUgYWdlbnQgdXNpbmcgdGhlIHN0cmF0ZWd5LlxyXG4gICAgICogQHBhcmFtIF9ydW5Bd2F5RnJvbSBUaGUgbm9kZSBmb3IgdGhlIGFnZW50IHRvIHJ1biBhd2F5IGZyb20uXHJcbiAgICAgKi9cclxuICAgIGNvbnN0cnVjdG9yKF9hZ2VudDogQWdlbnQsIF9ydW5Bd2F5RnJvbTogY2MuTm9kZSkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5fYWdlbnQgPSBfYWdlbnQ7XHJcbiAgICAgICAgdGhpcy5fcnVuQXdheUZyb20gPSBfcnVuQXdheUZyb207XHJcbiAgICB9XHJcblxyXG4gICAgcHJpdmF0ZSBfbW92ZUF4aXMyRDogY2MuVmVjMiA9IGNjLlZlYzIuWkVSTztcclxuXHJcbiAgICBwdWJsaWMgZ2V0IGF3YXlGcm9tVGFyZ2V0KCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9hZ2VudC5ub2RlLnBvc2l0aW9uLnN1Yih0aGlzLl9ydW5Bd2F5RnJvbS5wb3NpdGlvbikubm9ybWFsaXplKCk7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIGdldCBkaXN0YW5jZUZyb21UYXJnZXQoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3J1bkF3YXlGcm9tLnBvc2l0aW9uLnN1Yih0aGlzLl9hZ2VudC5ub2RlLnBvc2l0aW9uKS5tYWcoKVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICBwdWJsaWMgZ2V0IGhvcml6b250YWxBeGlzKCk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX21vdmVBeGlzMkQueDtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXQgdmVydGljYWxBeGlzKCk6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX21vdmVBeGlzMkQueTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXQgYXR0YWNrKCk6IEJ1dHRvblN0YXRlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNZXRob2Qgbm90IGltcGxlbWVudGVkLlwiKTtcclxuICAgIH1cclxuICAgIHB1YmxpYyBnZXQgaW50ZXJhY3QoKTogQnV0dG9uU3RhdGUge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIk1ldGhvZCBub3QgaW1wbGVtZW50ZWQuXCIpO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHN0YXJ0KCk6IHZvaWQge1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgdGhpcy5fbW92ZUF4aXMyRCA9IHRoaXMuYXdheUZyb21UYXJnZXQ7XHJcbiAgICB9XHJcblxyXG59Il19