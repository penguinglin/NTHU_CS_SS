
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ai/strategies/Wanderer.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1f7aasmeZhNIoYFA83XzaqQ', 'Wanderer');
// scripts/ai/strategies/Wanderer.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.Wanderer = void 0;
var AgentStrategy_1 = require("./AgentStrategy");
/**
 * An AI strategy that describes a "wandering" behaviour.
 */
var Wanderer = /** @class */ (function (_super) {
    __extends(Wanderer, _super);
    function Wanderer(moveDuration, waitDuration, waitRandomFactor) {
        var _this = _super.call(this) || this;
        /** The agent will move for this long before stopping to wait. */
        _this._moveDuration = 1.0;
        /** The agent will wait for this long before starting to move again. */
        _this._waitDuration = 0.5;
        /** The actual wait duration will be randomized by this factor,
         *  such that the actual wait duration is a random number between
         *  waitDuration x (1 - waitRandomFactor) and
         *  waitDuration x (1 + waitRandomFactor).
        */
        _this._waitRandomFactor = 0.1;
        /** The time point after which the agent should wait. */
        _this._nextWaitTime = 0;
        /** The time point after which the agent should move again. */
        _this._nextMoveTime = 0;
        /** The velocity (vector with magnitude) at which the agent should move. */
        _this._wanderVelocity = cc.Vec2.ZERO;
        /** The agent's output to IInput. */
        _this._moveAxis2D = cc.Vec2.ZERO;
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (1.1): Complete the constructor.
        // [SPECIFICATIONS]
        // - Initialize the four private variables above properly.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        _this._moveDuration = moveDuration;
        _this._waitDuration = waitDuration;
        _this._waitRandomFactor = waitRandomFactor;
        return _this;
    }
    Object.defineProperty(Wanderer.prototype, "horizontalAxis", {
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (1.2): Map moveAxis2D to horizontal and vertical axes.
        // [SPECIFICATIONS]
        // - moveAxis2D.x should be mapped to the horizontal axis.
        // - moveAxis2D.y should be mapped to the vertical axis.
        // - You can leave the remaining unimplemented.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        get: function () {
            return this._moveAxis2D.x;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Wanderer.prototype, "verticalAxis", {
        get: function () {
            return this._moveAxis2D.y;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Wanderer.prototype, "attack", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Wanderer.prototype, "interact", {
        get: function () {
            throw new Error("Method not implemented.");
        },
        enumerable: false,
        configurable: true
    });
    Wanderer.prototype.start = function () {
        this._nextMoveTime = cc.director.getTotalTime() / 1000.0;
        this._nextWaitTime = this._nextMoveTime - this._waitDuration;
    };
    Wanderer.prototype.update = function (dt) {
        /** The current time in the game in seconds. */
        var currentTime = cc.director.getTotalTime() / 1000.0;
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        // TODO (1.3): Implement the behaviour of a wandering agent.
        // [SPECIFICATIONS]
        // 1. The agent should recompute its wandering direction when the
        //    current time (curTime) reaches the next move time (this.nextMoveTime)
        //     - When this happens, recompute the next move time and the next wait 
        //       time.
        //     - Compute the wandering direction as a random 2D vector using the
        //       provided function "randomPointOnCircle".
        // 2. The agent's movement axes (this.moveAxis2D)
        //    should be equal to the wander velocity (this.wanderVelocity) before
        //    the next wait time (this.nextWaitTime). 
        //    OTHERWISE it should be equal to cc.Vec2.ZERO.
        //*||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||*\\
        //#region [YOUR IMPLEMENTATION HERE]
        if (currentTime >= this._nextMoveTime) {
            // Compute the next scheduled wait time.
            this._nextWaitTime = currentTime + this._moveDuration;
            // Compute the next scheduled move time.
            this._nextMoveTime = this._nextWaitTime
                + this._waitDuration // time spent waiting after moving (slightly randomized)
                    * (1.0 + this._waitRandomFactor * (Math.random() * 2.0 - 1.0));
            // Set new move direction.
            this._wanderVelocity = randomPointOnUnitCircle();
        }
        this._moveAxis2D =
            (currentTime < this._nextWaitTime) ? this._wanderVelocity
                : cc.Vec2.ZERO;
        //#endregion
    };
    return Wanderer;
}(AgentStrategy_1.AI.Strategy));
exports.Wanderer = Wanderer;
function randomPointOnUnitCircle() {
    var angle = Math.random() * Math.PI * 2;
    return new cc.Vec2(Math.cos(angle), Math.sin(angle));
}

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcYWlcXHN0cmF0ZWdpZXNcXFdhbmRlcmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUEsaURBQXFDO0FBRXJDOztHQUVHO0FBQ0g7SUFBOEIsNEJBQVc7SUFZckMsa0JBQVksWUFBbUIsRUFBRSxZQUFtQixFQUFFLGdCQUF1QjtRQUE3RSxZQUNJLGlCQUFPLFNBU1Y7UUFyQkQsaUVBQWlFO1FBQ3pELG1CQUFhLEdBQUcsR0FBRyxDQUFDO1FBQzVCLHVFQUF1RTtRQUMvRCxtQkFBYSxHQUFHLEdBQUcsQ0FBQztRQUM1Qjs7OztVQUlFO1FBQ08sdUJBQWlCLEdBQUcsR0FBRyxDQUFDO1FBY2pDLHdEQUF3RDtRQUNoRCxtQkFBYSxHQUFHLENBQUMsQ0FBQztRQUMxQiw4REFBOEQ7UUFDdEQsbUJBQWEsR0FBRyxDQUFDLENBQUM7UUFDMUIsMkVBQTJFO1FBQ25FLHFCQUFlLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdkMsb0NBQW9DO1FBQzVCLGlCQUFXLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFqQi9CLDRFQUE0RTtRQUM1RSx3Q0FBd0M7UUFDeEMsbUJBQW1CO1FBQ25CLDBEQUEwRDtRQUMxRCw0RUFBNEU7UUFDNUUsS0FBSSxDQUFDLGFBQWEsR0FBRyxZQUFZLENBQUM7UUFDbEMsS0FBSSxDQUFDLGFBQWEsR0FBRyxZQUFZLENBQUM7UUFDbEMsS0FBSSxDQUFDLGlCQUFpQixHQUFHLGdCQUFnQixDQUFDOztJQUM5QyxDQUFDO0lBa0JELHNCQUFXLG9DQUFjO1FBUHpCLDRFQUE0RTtRQUM1RSw4REFBOEQ7UUFDOUQsbUJBQW1CO1FBQ25CLDBEQUEwRDtRQUMxRCx3REFBd0Q7UUFDeEQsK0NBQStDO1FBQy9DLDRFQUE0RTthQUM1RTtZQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDOUIsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVyxrQ0FBWTthQUF2QjtZQUNJLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFDOUIsQ0FBQzs7O09BQUE7SUFDRCxzQkFBVyw0QkFBTTthQUFqQjtZQUNJLE1BQU0sSUFBSSxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQztRQUMvQyxDQUFDOzs7T0FBQTtJQUNELHNCQUFXLDhCQUFRO2FBQW5CO1lBQ0ksTUFBTSxJQUFJLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1FBQy9DLENBQUM7OztPQUFBO0lBRU0sd0JBQUssR0FBWjtRQUNJLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsR0FBRyxNQUFNLENBQUM7UUFDekQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7SUFDakUsQ0FBQztJQUNNLHlCQUFNLEdBQWIsVUFBYyxFQUFVO1FBQ3BCLCtDQUErQztRQUMvQyxJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxHQUFHLE1BQU0sQ0FBQztRQUV0RCw0RUFBNEU7UUFDNUUsNERBQTREO1FBQzVELG1CQUFtQjtRQUNuQixpRUFBaUU7UUFDakUsMkVBQTJFO1FBQzNFLDJFQUEyRTtRQUMzRSxjQUFjO1FBQ2Qsd0VBQXdFO1FBQ3hFLGlEQUFpRDtRQUNqRCxpREFBaUQ7UUFDakQseUVBQXlFO1FBQ3pFLDhDQUE4QztRQUM5QyxtREFBbUQ7UUFDbkQsNEVBQTRFO1FBRTVFLG9DQUFvQztRQUNwQyxJQUFJLFdBQVcsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ25DLHdDQUF3QztZQUN4QyxJQUFJLENBQUMsYUFBYSxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQ3RELHdDQUF3QztZQUN4QyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhO2tCQUNqQyxJQUFJLENBQUMsYUFBYSxDQUFDLHdEQUF3RDtzQkFDM0UsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBRW5FLDBCQUEwQjtZQUMxQixJQUFJLENBQUMsZUFBZSxHQUFHLHVCQUF1QixFQUFFLENBQUM7U0FDcEQ7UUFFRCxJQUFJLENBQUMsV0FBVztZQUNaLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWU7Z0JBQ3JELENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUV2QixZQUFZO0lBQ2hCLENBQUM7SUFFTCxlQUFDO0FBQUQsQ0FoR0EsQUFnR0MsQ0FoRzZCLGtCQUFFLENBQUMsUUFBUSxHQWdHeEM7QUFoR1ksNEJBQVE7QUFrR3JCLFNBQVMsdUJBQXVCO0lBQzVCLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUN4QyxPQUFPLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uU3RhdGUgfSBmcm9tIFwiLi4vLi4vaW5wdXQvSUlucHV0Q29udHJvbHNcIjtcclxuaW1wb3J0IEFnZW50IGZyb20gXCIuLi9BZ2VudFwiO1xyXG5pbXBvcnQgeyBBSSB9IGZyb20gXCIuL0FnZW50U3RyYXRlZ3lcIjtcclxuXHJcbi8qKlxyXG4gKiBBbiBBSSBzdHJhdGVneSB0aGF0IGRlc2NyaWJlcyBhIFwid2FuZGVyaW5nXCIgYmVoYXZpb3VyLlxyXG4gKi9cclxuZXhwb3J0IGNsYXNzIFdhbmRlcmVyIGV4dGVuZHMgQUkuU3RyYXRlZ3l7XHJcbiAgICAvKiogVGhlIGFnZW50IHdpbGwgbW92ZSBmb3IgdGhpcyBsb25nIGJlZm9yZSBzdG9wcGluZyB0byB3YWl0LiAqL1xyXG4gICAgcHJpdmF0ZSBfbW92ZUR1cmF0aW9uID0gMS4wO1xyXG4gICAgLyoqIFRoZSBhZ2VudCB3aWxsIHdhaXQgZm9yIHRoaXMgbG9uZyBiZWZvcmUgc3RhcnRpbmcgdG8gbW92ZSBhZ2Fpbi4gKi9cclxuICAgIHByaXZhdGUgX3dhaXREdXJhdGlvbiA9IDAuNTtcclxuICAgIC8qKiBUaGUgYWN0dWFsIHdhaXQgZHVyYXRpb24gd2lsbCBiZSByYW5kb21pemVkIGJ5IHRoaXMgZmFjdG9yLCBcclxuICAgICAqICBzdWNoIHRoYXQgdGhlIGFjdHVhbCB3YWl0IGR1cmF0aW9uIGlzIGEgcmFuZG9tIG51bWJlciBiZXR3ZWVuXHJcbiAgICAgKiAgd2FpdER1cmF0aW9uIHggKDEgLSB3YWl0UmFuZG9tRmFjdG9yKSBhbmQgXHJcbiAgICAgKiAgd2FpdER1cmF0aW9uIHggKDEgKyB3YWl0UmFuZG9tRmFjdG9yKS5cclxuICAgICovXHJcbiAgICAgcHJpdmF0ZSBfd2FpdFJhbmRvbUZhY3RvciA9IDAuMTtcclxuXHJcbiAgICBjb25zdHJ1Y3Rvcihtb3ZlRHVyYXRpb246bnVtYmVyLCB3YWl0RHVyYXRpb246bnVtYmVyLCB3YWl0UmFuZG9tRmFjdG9yOm51bWJlcikge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXHJcbiAgICAgICAgLy8gVE9ETyAoMS4xKTogQ29tcGxldGUgdGhlIGNvbnN0cnVjdG9yLlxyXG4gICAgICAgIC8vIFtTUEVDSUZJQ0FUSU9OU11cclxuICAgICAgICAvLyAtIEluaXRpYWxpemUgdGhlIGZvdXIgcHJpdmF0ZSB2YXJpYWJsZXMgYWJvdmUgcHJvcGVybHkuXHJcbiAgICAgICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXHJcbiAgICAgICAgdGhpcy5fbW92ZUR1cmF0aW9uID0gbW92ZUR1cmF0aW9uO1xyXG4gICAgICAgIHRoaXMuX3dhaXREdXJhdGlvbiA9IHdhaXREdXJhdGlvbjtcclxuICAgICAgICB0aGlzLl93YWl0UmFuZG9tRmFjdG9yID0gd2FpdFJhbmRvbUZhY3RvcjtcclxuICAgIH1cclxuXHJcbiAgICAvKiogVGhlIHRpbWUgcG9pbnQgYWZ0ZXIgd2hpY2ggdGhlIGFnZW50IHNob3VsZCB3YWl0LiAqL1xyXG4gICAgcHJpdmF0ZSBfbmV4dFdhaXRUaW1lID0gMDtcclxuICAgIC8qKiBUaGUgdGltZSBwb2ludCBhZnRlciB3aGljaCB0aGUgYWdlbnQgc2hvdWxkIG1vdmUgYWdhaW4uICovXHJcbiAgICBwcml2YXRlIF9uZXh0TW92ZVRpbWUgPSAwO1xyXG4gICAgLyoqIFRoZSB2ZWxvY2l0eSAodmVjdG9yIHdpdGggbWFnbml0dWRlKSBhdCB3aGljaCB0aGUgYWdlbnQgc2hvdWxkIG1vdmUuICovXHJcbiAgICBwcml2YXRlIF93YW5kZXJWZWxvY2l0eSA9IGNjLlZlYzIuWkVSTztcclxuICAgIC8qKiBUaGUgYWdlbnQncyBvdXRwdXQgdG8gSUlucHV0LiAqL1xyXG4gICAgcHJpdmF0ZSBfbW92ZUF4aXMyRCA9IGNjLlZlYzIuWkVSTztcclxuXHJcbiAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcclxuICAgIC8vIFRPRE8gKDEuMik6IE1hcCBtb3ZlQXhpczJEIHRvIGhvcml6b250YWwgYW5kIHZlcnRpY2FsIGF4ZXMuXHJcbiAgICAvLyBbU1BFQ0lGSUNBVElPTlNdXHJcbiAgICAvLyAtIG1vdmVBeGlzMkQueCBzaG91bGQgYmUgbWFwcGVkIHRvIHRoZSBob3Jpem9udGFsIGF4aXMuXHJcbiAgICAvLyAtIG1vdmVBeGlzMkQueSBzaG91bGQgYmUgbWFwcGVkIHRvIHRoZSB2ZXJ0aWNhbCBheGlzLlxyXG4gICAgLy8gLSBZb3UgY2FuIGxlYXZlIHRoZSByZW1haW5pbmcgdW5pbXBsZW1lbnRlZC5cclxuICAgIC8vKnx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHwqXFxcXFxyXG4gICAgcHVibGljIGdldCBob3Jpem9udGFsQXhpcygpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELng7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgZ2V0IHZlcnRpY2FsQXhpcygpOiBudW1iZXIge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9tb3ZlQXhpczJELnk7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgZ2V0IGF0dGFjaygpOiBCdXR0b25TdGF0ZSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kIG5vdCBpbXBsZW1lbnRlZC5cIik7XHJcbiAgICB9XHJcbiAgICBwdWJsaWMgZ2V0IGludGVyYWN0KCk6IEJ1dHRvblN0YXRlIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNZXRob2Qgbm90IGltcGxlbWVudGVkLlwiKTtcclxuICAgIH1cclxuXHJcbiAgICBwdWJsaWMgc3RhcnQoKSB7XHJcbiAgICAgICAgdGhpcy5fbmV4dE1vdmVUaW1lID0gY2MuZGlyZWN0b3IuZ2V0VG90YWxUaW1lKCkgLyAxMDAwLjA7XHJcbiAgICAgICAgdGhpcy5fbmV4dFdhaXRUaW1lID0gdGhpcy5fbmV4dE1vdmVUaW1lIC0gdGhpcy5fd2FpdER1cmF0aW9uO1xyXG4gICAgfVxyXG4gICAgcHVibGljIHVwZGF0ZShkdDogbnVtYmVyKSB7XHJcbiAgICAgICAgLyoqIFRoZSBjdXJyZW50IHRpbWUgaW4gdGhlIGdhbWUgaW4gc2Vjb25kcy4gKi9cclxuICAgICAgICBsZXQgY3VycmVudFRpbWUgPSBjYy5kaXJlY3Rvci5nZXRUb3RhbFRpbWUoKSAvIDEwMDAuMDtcclxuXHJcbiAgICAgICAgLy8qfHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fCpcXFxcXHJcbiAgICAgICAgLy8gVE9ETyAoMS4zKTogSW1wbGVtZW50IHRoZSBiZWhhdmlvdXIgb2YgYSB3YW5kZXJpbmcgYWdlbnQuXHJcbiAgICAgICAgLy8gW1NQRUNJRklDQVRJT05TXVxyXG4gICAgICAgIC8vIDEuIFRoZSBhZ2VudCBzaG91bGQgcmVjb21wdXRlIGl0cyB3YW5kZXJpbmcgZGlyZWN0aW9uIHdoZW4gdGhlXHJcbiAgICAgICAgLy8gICAgY3VycmVudCB0aW1lIChjdXJUaW1lKSByZWFjaGVzIHRoZSBuZXh0IG1vdmUgdGltZSAodGhpcy5uZXh0TW92ZVRpbWUpXHJcbiAgICAgICAgLy8gICAgIC0gV2hlbiB0aGlzIGhhcHBlbnMsIHJlY29tcHV0ZSB0aGUgbmV4dCBtb3ZlIHRpbWUgYW5kIHRoZSBuZXh0IHdhaXQgXHJcbiAgICAgICAgLy8gICAgICAgdGltZS5cclxuICAgICAgICAvLyAgICAgLSBDb21wdXRlIHRoZSB3YW5kZXJpbmcgZGlyZWN0aW9uIGFzIGEgcmFuZG9tIDJEIHZlY3RvciB1c2luZyB0aGVcclxuICAgICAgICAvLyAgICAgICBwcm92aWRlZCBmdW5jdGlvbiBcInJhbmRvbVBvaW50T25DaXJjbGVcIi5cclxuICAgICAgICAvLyAyLiBUaGUgYWdlbnQncyBtb3ZlbWVudCBheGVzICh0aGlzLm1vdmVBeGlzMkQpXHJcbiAgICAgICAgLy8gICAgc2hvdWxkIGJlIGVxdWFsIHRvIHRoZSB3YW5kZXIgdmVsb2NpdHkgKHRoaXMud2FuZGVyVmVsb2NpdHkpIGJlZm9yZVxyXG4gICAgICAgIC8vICAgIHRoZSBuZXh0IHdhaXQgdGltZSAodGhpcy5uZXh0V2FpdFRpbWUpLiBcclxuICAgICAgICAvLyAgICBPVEhFUldJU0UgaXQgc2hvdWxkIGJlIGVxdWFsIHRvIGNjLlZlYzIuWkVSTy5cclxuICAgICAgICAvLyp8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8fHx8KlxcXFxcclxuICAgICAgICBcclxuICAgICAgICAvLyNyZWdpb24gW1lPVVIgSU1QTEVNRU5UQVRJT04gSEVSRV1cclxuICAgICAgICBpZiAoY3VycmVudFRpbWUgPj0gdGhpcy5fbmV4dE1vdmVUaW1lKSB7XHJcbiAgICAgICAgICAgIC8vIENvbXB1dGUgdGhlIG5leHQgc2NoZWR1bGVkIHdhaXQgdGltZS5cclxuICAgICAgICAgICAgdGhpcy5fbmV4dFdhaXRUaW1lID0gY3VycmVudFRpbWUgKyB0aGlzLl9tb3ZlRHVyYXRpb247XHJcbiAgICAgICAgICAgIC8vIENvbXB1dGUgdGhlIG5leHQgc2NoZWR1bGVkIG1vdmUgdGltZS5cclxuICAgICAgICAgICAgdGhpcy5fbmV4dE1vdmVUaW1lID0gdGhpcy5fbmV4dFdhaXRUaW1lXHJcbiAgICAgICAgICAgICAgICArIHRoaXMuX3dhaXREdXJhdGlvbiAvLyB0aW1lIHNwZW50IHdhaXRpbmcgYWZ0ZXIgbW92aW5nIChzbGlnaHRseSByYW5kb21pemVkKVxyXG4gICAgICAgICAgICAgICAgKiAoMS4wICsgdGhpcy5fd2FpdFJhbmRvbUZhY3RvciAqIChNYXRoLnJhbmRvbSgpICogMi4wIC0gMS4wKSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvLyBTZXQgbmV3IG1vdmUgZGlyZWN0aW9uLlxyXG4gICAgICAgICAgICB0aGlzLl93YW5kZXJWZWxvY2l0eSA9IHJhbmRvbVBvaW50T25Vbml0Q2lyY2xlKCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aGlzLl9tb3ZlQXhpczJEID1cclxuICAgICAgICAgICAgKGN1cnJlbnRUaW1lIDwgdGhpcy5fbmV4dFdhaXRUaW1lKSA/IHRoaXMuX3dhbmRlclZlbG9jaXR5XHJcbiAgICAgICAgICAgICAgICA6IGNjLlZlYzIuWkVSTztcclxuICAgICAgICBcclxuICAgICAgICAvLyNlbmRyZWdpb25cclxuICAgIH1cclxuXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJhbmRvbVBvaW50T25Vbml0Q2lyY2xlKCkge1xyXG4gICAgbGV0IGFuZ2xlID0gTWF0aC5yYW5kb20oKSAqIE1hdGguUEkgKiAyO1xyXG4gICAgcmV0dXJuIG5ldyBjYy5WZWMyKE1hdGguY29zKGFuZ2xlKSwgTWF0aC5zaW4oYW5nbGUpKTtcclxufSJdfQ==